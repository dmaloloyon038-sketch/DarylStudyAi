// Links students can attach: Canva, Google Drive / Docs, and YouTube.
// Only the web address is checked and saved. Nothing is uploaded.

const SERVICES = [
  {
    id: "canva",
    label: "Canva",
    hosts: ["canva.com", "www.canva.com", "canva.link"]
  },
  {
    id: "drive",
    label: "Google Drive",
    hosts: ["drive.google.com", "docs.google.com"]
  },
  {
    id: "youtube",
    label: "YouTube",
    hosts: ["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"]
  }
];

export function serviceLabel(id) {
  const service = SERVICES.find((s) => s.id === id);
  return service ? service.label : "Link";
}

// Checks a pasted link.
// Returns { service, url } for a good link, or { error } with a message.
export function parseLink(text) {
  const raw = String(text || "").trim();

  if (!raw) return { error: "Paste a link first." };
  if (raw.length > 500) return { error: "That link is too long." };

  // Allow "canva.link/abc" without https://
  const hasScheme = /^[a-z][a-z0-9+.-]*:/i.test(raw);

  let url;
  try {
    url = new URL(hasScheme ? raw : "https://" + raw);
  } catch {
    return { error: "That does not look like a link." };
  }

  if (url.protocol !== "https:") {
    return { error: "Use a link that starts with https://" };
  }

  if (url.username || url.password || url.port) {
    return { error: "That link is not allowed." };
  }

  const host = url.hostname.toLowerCase();
  const service = SERVICES.find((s) => s.hosts.includes(host));

  if (!service) {
    return { error: "Only Canva, Google Drive and YouTube links are supported." };
  }

  return { service: service.id, url: url.href };
}