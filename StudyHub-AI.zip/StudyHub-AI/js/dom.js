// Small helpers for building page elements safely.
// Using textContent (not innerHTML) keeps user text from running as code.

export function el(tag, className = "", text = "") {
  const node = document.createElement(tag);

  if (className) node.className = className;
  if (text) node.textContent = text;

  return node;
}

// Creates a Lucide icon placeholder. Call refreshIcons() afterwards.
export function icon(name) {
  const node = document.createElement("i");
  node.setAttribute("data-lucide", name);
  return node;
}

export function refreshIcons() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}