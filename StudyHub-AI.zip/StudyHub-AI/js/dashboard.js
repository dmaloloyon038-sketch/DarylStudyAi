// Dashboard: every number comes from your Firestore data.

import { requireAuth } from "./auth-guard.js";
import { renderShell, greeting } from "./layout.js";
import { userCol, safeColor, toDate, shortDate, shortDateTime } from "./firestore.js";
import { el, icon, refreshIcons } from "./dom.js";

import {
  getDocs,
  getCountFromServer,
  query,
  orderBy,
  where,
  limit,
  Timestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $ = (id) => document.getElementById(id);

/* ---------- Sign-in and page shell ---------- */

const user = await requireAuth();
const uid = user.uid;

renderShell(user, "dashboard.html");

const welcome = greeting(user);
$("hello").textContent = welcome.title;
$("today").textContent = welcome.date;

/* ---------- Stat cards (show a loading skeleton first) ---------- */

const STATS = [
  ["subjects",  "Subjects",              "book-open"],
  ["notes",     "Saved notes",           "notebook-pen"],
  ["pending",   "Pending activities",    "list-checks"],
  ["upcoming",  "Upcoming deadlines",    "calendar-clock"],
  ["completed", "Completed assignments", "circle-check"]
];

const statValues = {};

for (const [key, label, iconName] of STATS) {
  const card = el("div", "card stat");

  const iconBox = el("span", "stat-icon");
  iconBox.append(icon(iconName));

  const value = el("div", "stat-value skeleton", "\u00a0");
  statValues[key] = value;

  card.append(iconBox, value, el("div", "stat-label", label));
  $("stats").append(card);
}

function setStat(key, text) {
  statValues[key].classList.remove("skeleton");
  statValues[key].textContent = String(text);
}

/* ---------- Small builders ---------- */

function listRow({ title, parts, color, badgeText, badgeKind }) {
  const row = el("div", "list-item");

  const dot = el("span", "dot");
  dot.style.background = safeColor(color);

  const main = el("div", "list-main");
  main.append(el("div", "row-title", title));

  const meta = el("div", "row-meta");
  parts.filter(Boolean).forEach((p) => meta.append(el("span", "", p)));
  main.append(meta);

  row.append(dot, main);

  if (badgeText) {
    row.append(el("span", "badge badge-" + badgeKind, badgeText));
  }

  return row;
}

function fillList(id, rows, emptyTitle, emptyText) {
  const box = $(id);
  box.replaceChildren();

  if (rows.length === 0) {
    const empty = el("div", "empty small");
    empty.append(el("h3", "", emptyTitle), el("p", "", emptyText));
    box.append(empty);
    return;
  }

  rows.forEach((row) => box.append(listRow(row)));
}

function showError(id) {
  const box = $(id);
  box.replaceChildren();

  const empty = el("div", "empty small");
  empty.append(el("p", "", "Could not load this section. Refresh to try again."));
  box.append(empty);
}

/* ---------- Load everything at the same time ---------- */

const now = new Date();

// Start of the day, 6 days ago (the chart shows 7 days including today)
const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6);

const [
  subjectsRes,
  notesCountRes,
  recentNotesRes,
  activitiesRes,
  eventsRes,
  sessionsRes
] = await Promise.allSettled([
  getDocs(query(userCol(uid, "subjects"), limit(200))),
  getCountFromServer(userCol(uid, "notes")),
  getDocs(query(userCol(uid, "notes"), orderBy("updatedAt", "desc"), limit(5))),
  getDocs(query(userCol(uid, "activities"), limit(500))),
  getDocs(query(
    userCol(uid, "events"),
    where("start", ">=", Timestamp.now()),
    orderBy("start", "asc"),
    limit(5)
  )),
  getDocs(query(
    userCol(uid, "studySessions"),
    where("startedAt", ">=", Timestamp.fromDate(weekStart)),
    limit(500)
  ))
]);

/* ---------- Subjects (used to show names and colors) ---------- */

const subjectMap = new Map();

if (subjectsRes.status === "fulfilled") {
  subjectsRes.value.docs.forEach((d) => subjectMap.set(d.id, d.data()));
  setStat("subjects", subjectMap.size);
} else {
  setStat("subjects", "–");
}

const subjectName = (id) => subjectMap.get(id)?.name || "";
const subjectColor = (id) => subjectMap.get(id)?.color;

/* ---------- Notes ---------- */

let notesCount = 0;

if (notesCountRes.status === "fulfilled") {
  notesCount = notesCountRes.value.data().count;
  setStat("notes", notesCount);
} else {
  setStat("notes", "–");
}

if (recentNotesRes.status === "fulfilled") {
  const rows = recentNotesRes.value.docs.map((d) => {
    const note = d.data();
    return {
      title: note.title,
      parts: [
        subjectName(note.subjectId),
        "Updated " + shortDate(toDate(note.updatedAt))
      ],
      color: subjectColor(note.subjectId)
    };
  });

  fillList("notes", rows, "No notes yet", "Notes you write will show up here.");
} else {
  showError("notes");
}

/* ---------- Activities and deadlines ---------- */

let overdue = [];
let upcoming = [];

if (activitiesRes.status === "fulfilled") {
  const all = activitiesRes.value.docs.map((d) => ({ id: d.id, ...d.data() }));

  const pending = all.filter((a) => a.status !== "completed");
  const completed = all.filter((a) => a.status === "completed");

  // Pending activities that have a deadline, earliest first
  const withDeadline = pending
    .filter((a) => toDate(a.deadline))
    .map((a) => ({ ...a, due: toDate(a.deadline) }))
    .sort((a, b) => a.due - b.due);

  overdue = withDeadline.filter((a) => a.due < now);
  upcoming = withDeadline.filter((a) => a.due >= now);

  setStat("pending", pending.length);
  setStat("upcoming", upcoming.length);
  setStat("completed", completed.length);

  const rows = withDeadline.slice(0, 5).map((a) => ({
    title: a.title,
    parts: [subjectName(a.subjectId), "Due " + shortDate(a.due)],
    color: subjectColor(a.subjectId),
    badgeText: a.due < now ? "Overdue" : "",
    badgeKind: "danger"
  }));

  fillList(
    "deadlines",
    rows,
    "No deadlines",
    "Activities with a due date will show up here."
  );
} else {
  setStat("pending", "–");
  setStat("upcoming", "–");
  setStat("completed", "–");
  showError("deadlines");
}

/* ---------- Upcoming events ---------- */

if (eventsRes.status === "fulfilled") {
  const rows = eventsRes.value.docs.map((d) => {
    const event = d.data();
    return {
      title: event.title,
      parts: [subjectName(event.subjectId), shortDateTime(toDate(event.start))],
      color: subjectColor(event.subjectId)
    };
  });

  fillList(
    "events",
    rows,
    "No upcoming events",
    "Exams and study sessions you schedule will show up here."
  );
} else {
  showError("events");
}

/* ---------- Study time chart (last 7 days) ---------- */

const minutesPerDay = new Array(7).fill(0);

if (sessionsRes.status === "fulfilled") {
  sessionsRes.value.docs.forEach((d) => {
    const session = d.data();
    const started = toDate(session.startedAt);
    if (!started) return;

    const dayStart = new Date(
      started.getFullYear(), started.getMonth(), started.getDate()
    );
    const index = Math.round((dayStart - weekStart) / 86400000);

    if (index >= 0 && index < 7) {
      minutesPerDay[index] += Number(session.actualMinutes) || 0;
    }
  });

  const totalMinutes = minutesPerDay.reduce((sum, m) => sum + m, 0);

  if (totalMinutes === 0) {
    $("chart-box").hidden = true;

    const empty = el("div", "empty small");
    empty.append(
      el("h3", "", "No study time yet"),
      el("p", "", "Completed study sessions will appear in this chart.")
    );
    $("study-empty").append(empty);
  } else if (window.Chart) {
    const labels = minutesPerDay.map((_, i) => {
      const day = new Date(weekStart);
      day.setDate(weekStart.getDate() + i);
      return day.toLocaleDateString(undefined, { weekday: "short" });
    });

    const hours = minutesPerDay.map((m) => Math.round((m / 60) * 10) / 10);

    const css = getComputedStyle(document.documentElement);
    const primary = css.getPropertyValue("--primary").trim();
    const muted = css.getPropertyValue("--muted").trim();

    new Chart($("study-chart"), {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Hours",
          data: hours,
          backgroundColor: primary,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: muted }, grid: { display: false } },
          y: { beginAtZero: true, ticks: { color: muted } }
        }
      }
    });
  }
} else {
  $("chart-box").hidden = true;
  showError("study-empty");
}

/* ---------- Study suggestions (simple rules, based on your data) ---------- */

const weekMinutes = minutesPerDay.reduce((sum, m) => sum + m, 0);
const tips = [];

if (subjectMap.size === 0) {
  tips.push("Add your first subject to start organizing notes and tasks.");
}

if (overdue.length > 0) {
  const plural = overdue.length === 1 ? "task is" : "tasks are";
  tips.push(
    `${overdue.length} ${plural} overdue. Start with "${overdue[0].title}".`
  );
}

if (upcoming.length > 0) {
  const next = upcoming[0];
  const days = (next.due - now) / 86400000;

  if (days <= 3) {
    tips.push(
      `"${next.title}" is due ${shortDate(next.due)}. Plan time to work on it.`
    );
  }
}

if (subjectMap.size > 0 && notesCount === 0) {
  tips.push("Add notes to a subject so you can review and quiz yourself later.");
}

if (subjectMap.size > 0 && weekMinutes === 0) {
  tips.push("You haven't logged study time this week. Try one 25-minute focus session.");
}

if (tips.length === 0) {
  tips.push("You're all caught up. Review a recent note to keep it fresh.");
}

tips.forEach((text) => {
  const row = el("div", "suggestion");
  row.append(icon("sparkles"), el("p", "", text));
  $("suggestions").append(row);
});

refreshIcons();