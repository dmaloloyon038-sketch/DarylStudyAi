
// Pure helper functions for the calendar page.
// Separated to keep calculations clean and easy to test.

export const EVENT_TYPES = [
  { id: "exam", label: "Exam" },
  { id: "study", label: "Study session" },
  { id: "deadline", label: "Deadline" },
  { id: "other", label: "Other" }
];

export const typeLabel = (id) => (EVENT_TYPES.find((t) => t.id === id) || EVENT_TYPES[3]).label;

const pad = (n) => String(n).padStart(2, "0");

// Convert Date object -> "2026-11-12T09:00" for datetime-local input
export function toDateTimeLocal(date) {
  if (!date) return "";
  return (
    `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` +
    `T${pad(date.getHours())}:${pad(date.getMinutes())}`
  );
}

// Convert "2026-11-12T09:00" -> Date object. Returns null if empty, undefined if invalid.
export function fromDateTimeLocal(text) {
  const value = String(text || "").trim();
  if (!value) return null;

  const date = new Date(value);
  return isNaN(date.getTime()) ? undefined : date;
}

// Check if two dates represent the exact same calendar day
export function isSameDay(d1, d2) {
  if (!d1 || !d2) return false;
  return (
    d1.getFullYear() === d2.getFullYear() &&
    d1.getMonth() === d2.getMonth() &&
    d1.getDate() === d2.getDate()
  );
}

// Generates 42 date objects representing the 6-week monthly grid
export function getCalendarGridDays(year, month) {
  const days = [];

  const firstDay = new Date(year, month, 1);
  const startingDayOfWeek = firstDay.getDay(); // 0 (Sun) to 6 (Sat)
  const prevMonthLastDay = new Date(year, month, 0).getDate();

  // 1. Trailing days from previous month
  for (let i = startingDayOfWeek - 1; i >= 0; i--) {
    days.push({
      date: new Date(year, month - 1, prevMonthLastDay - i),
      isCurrentMonth: false
    });
  }

  // 2. Days in current month
  const totalDays = new Date(year, month + 1, 0).getDate();
  for (let day = 1; day <= totalDays; day++) {
    days.push({
      date: new Date(year, month, day),
      isCurrentMonth: true
    });
  }

  // 3. Leading days for next month to complete 42 cells (6 rows x 7 days)
  const remainingCells = 42 - days.length;
  for (let day = 1; day <= remainingCells; day++) {
    days.push({
      date: new Date(year, month + 1, day),
      isCurrentMonth: false
    });
  }

  return days;
}

// Filter events by selected subject
export function filterEvents(events, subjectFilter) {
  return events.filter((e) => {
    if (subjectFilter === "none" && e.subjectId) return false;
    if (subjectFilter !== "all" && subjectFilter !== "none" && e.subjectId !== subjectFilter) return false;
    return true;
  });
}

// Validate event form input before saving
export function checkEvent({ title, startDateText, endDateText, type }) {
  const errors = {};
  const cleanTitle = String(title || "").trim();
  const start = fromDateTimeLocal(startDateText);
  const end = fromDateTimeLocal(endDateText);

  if (!cleanTitle) errors.title = "Please enter an event title.";
  else if (cleanTitle.length > 150) errors.title = "Keep title under 150 characters.";

  if (start === undefined) errors.start = "Enter a valid start date and time.";

  if (endDateText && end === undefined) {
    errors.end = "Enter a valid end date and time.";
  } else if (start && end && end < start) {
    errors.end = "End time cannot be earlier than start time.";
  }

  if (!EVENT_TYPES.some((t) => t.id === type)) {
    errors.type = "Choose a valid event type.";
  }

  return {
    errors,
    values: {
      title: cleanTitle,
      start: start === undefined ? null : start,
      end: end === undefined ? null : end,
      type
    }
  };
}
