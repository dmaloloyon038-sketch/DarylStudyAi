// Firebase client config is NOT a secret.
// Security comes from Auth + Security Rules + App Check.

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyBFqXGqFL2zExex20--VG6Z9I9s4GMKPOg",
  authDomain: "studyai-d6606.firebaseapp.com",
  projectId: "studyai-d6606",
  storageBucket: "studyai-d6606.firebasestorage.app",
  messagingSenderId: "548040074617",
  appId: "1:548040074617:web:5f299020180c6c4d227ba8"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);