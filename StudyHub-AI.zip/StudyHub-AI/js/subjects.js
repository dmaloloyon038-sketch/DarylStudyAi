// Subjects page: list, search, add, edit, delete.

import { db } from "./firebase-config.js";
import { requireAuth } from "./auth-guard.js";
import { renderShell } from "./layout.js";

import {
  userCol,
  userDoc,
  SUBJECT_COLORS,
  DEFAULT_COLOR,
  safeColor
} from "./firestore.js";

import { el, icon, refreshIcons } from "./dom.js";
import { toast, confirmModal, setLoading, fieldError } from "./utils.js";

import {
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  where,
  writeBatch,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $ = (id) => document.getElementById(id);

/* ---------- Sign-in and page shell ---------- */

const user = await requireAuth();
renderShell(user, "subjects.html");

/* ---------- State ---------- */

let subjects = [];    // all subjects loaded from Firestore
let editingId = null; // null = adding a new subject

const grid = $("subject-grid");
const dialog = $("subject-dialog");

/* =========================================
   LOAD AND SHOW SUBJECTS
   ========================================= */

function showSkeletons() {
  grid.replaceChildren();
  for (let i = 0; i < 3; i++) {
    grid.append(el("div", "skeleton skeleton-card"));
  }
}

async function loadSubjects() {
  showSkeletons();

  try {
    const snap = await getDocs(
      query(userCol(user.uid, "subjects"), orderBy("createdAt", "desc"))
    );

    subjects = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    render();
  } catch {
    grid.replaceChildren();

    const box = el("div", "card empty");
    box.append(
      el("h3", "", "Could not load subjects"),
      el("p", "", "Check your connection and try again.")
    );

    const retry = el("button", "btn btn-primary", "Try again");
    retry.type = "button";
    retry.style.marginTop = "16px";
    retry.onclick = loadSubjects;

    box.append(retry);
    grid.append(box);
  }
}

function emptyBox(title, text, buttonLabel, onClick) {
  const box = el("div", "card empty");
  box.append(el("h3", "", title), el("p", "", text));

  if (buttonLabel) {
    const button = el("button", "btn btn-primary", buttonLabel);
    button.type = "button";
    button.style.marginTop = "16px";
    button.onclick = onClick;
    box.append(button);
  }

  return box;
}

function subjectCard(subject) {
  const card = el("article", "card subject-card");
  card.style.setProperty("--subject-color", safeColor(subject.color));

  // Clicking the title opens the subject workspace
  const link = el("a", "subject-link");
  link.href = "subject-details.html?id=" + encodeURIComponent(subject.id);
  link.append(
    el("h3", "", subject.name),
    el("p", "muted subject-desc", subject.description || "No description yet.")
  );

  // Edit and delete buttons
  const actions = el("div", "card-actions");

  const editBtn = el("button", "icon-btn");
  editBtn.type = "button";
  editBtn.setAttribute("aria-label", "Edit " + subject.name);
  editBtn.append(icon("pencil"));
  editBtn.onclick = () => openDialog(subject);

  const deleteBtn = el("button", "icon-btn");
  deleteBtn.type = "button";
  deleteBtn.setAttribute("aria-label", "Delete " + subject.name);
  deleteBtn.append(icon("trash-2"));
  deleteBtn.onclick = () => removeSubject(subject);

  actions.append(editBtn, deleteBtn);
  card.append(link, actions);

  return card;
}

function render() {
  const term = $("search").value.trim().toLowerCase();

  const matches = subjects.filter((s) => {
    const name = (s.name || "").toLowerCase();
    const description = (s.description || "").toLowerCase();
    return name.includes(term) || description.includes(term);
  });

  grid.replaceChildren();

  if (subjects.length === 0) {
    grid.append(emptyBox(
      "No subjects yet",
      "Add your first subject to organize notes, tasks and deadlines.",
      "Add subject",
      () => openDialog()
    ));
  } else if (matches.length === 0) {
    grid.append(emptyBox("No matches", "Try a different search."));
  } else {
    matches.forEach((s) => grid.append(subjectCard(s)));
  }

  refreshIcons();
}

$("search").addEventListener("input", render);

/* =========================================
   ADD / EDIT DIALOG
   ========================================= */

const colorInput = $("s-color");
const swatchButtons = [];

function selectColor(color) {
  colorInput.value = color;

  swatchButtons.forEach((button) => {
    const selected = button.dataset.color.toLowerCase() === color.toLowerCase();
    button.setAttribute("aria-checked", String(selected));
  });
}

// Build the color circles once
SUBJECT_COLORS.forEach((color) => {
  const button = el("button", "swatch");
  button.type = "button";
  button.setAttribute("role", "radio");
  button.setAttribute("aria-label", "Color " + color);
  button.dataset.color = color;
  button.style.background = color;
  button.onclick = () => selectColor(color);

  $("swatches").insertBefore(button, colorInput);
  swatchButtons.push(button);
});

colorInput.addEventListener("input", () => selectColor(colorInput.value));

function openDialog(subject) {
  editingId = subject ? subject.id : null;

  $("dialog-title").textContent = subject ? "Edit subject" : "Add subject";
  $("s-name").value = subject ? subject.name : "";
  $("s-desc").value = subject ? subject.description || "" : "";
  selectColor(subject ? safeColor(subject.color) : DEFAULT_COLOR);

  fieldError($("s-name"), "");
  fieldError($("s-desc"), "");

  dialog.showModal();
  $("s-name").focus();
}

$("add-btn").addEventListener("click", () => openDialog());
$("cancel-btn").addEventListener("click", () => dialog.close());

$("subject-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = $("s-name").value.trim().replace(/\s+/g, " ");
  const description = $("s-desc").value.trim();
  const color = colorInput.value;
  const button = $("save-btn");

  const nameOk = name.length >= 1 && name.length <= 80;
  const descOk = description.length <= 500;

  fieldError($("s-name"), nameOk ? "" : "Enter a name (up to 80 characters).");
  fieldError($("s-desc"), descOk ? "" : "Keep the description under 500 characters.");

  if (!nameOk || !descOk) return;

  setLoading(button, true);

  try {
    if (editingId) {
      // Edit: ownerId and createdAt are left untouched
      await updateDoc(userDoc(user.uid, "subjects", editingId), {
        name: name,
        color: color,
        description: description,
        updatedAt: serverTimestamp()
      });
    } else {
      await addDoc(userCol(user.uid, "subjects"), {
        ownerId: user.uid,
        name: name,
        color: color,
        description: description,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }

    dialog.close();
    toast(editingId ? "Subject updated." : "Subject added.", "success");
    await loadSubjects();
  } catch {
    toast("Could not save the subject. Please try again.", "error");
  }

  setLoading(button, false, "Save subject");
});

/* =========================================
   DELETE
   ========================================= */

// Everything that belongs to a subject is deleted with it
const RELATED = ["notes", "activities", "events", "flashcards", "quizzes"];

async function deleteSubjectAndContents(subjectId) {
  for (const name of RELATED) {
    const snap = await getDocs(
      query(userCol(user.uid, name), where("subjectId", "==", subjectId))
    );

    // Firestore allows up to 500 deletes per batch
    for (let i = 0; i < snap.docs.length; i += 400) {
      const batch = writeBatch(db);
      snap.docs.slice(i, i + 400).forEach((d) => batch.delete(d.ref));
      await batch.commit();
    }
  }

  await deleteDoc(userDoc(user.uid, "subjects", subjectId));
}

async function removeSubject(subject) {
  const confirmed = await confirmModal({
    title: `Delete "${subject.name}"?`,
    message:
      "This also deletes its notes, activities, events, flashcards and quizzes. This cannot be undone.",
    confirmText: "Delete subject",
    danger: true
  });

  if (!confirmed) return;

  try {
    await deleteSubjectAndContents(subject.id);
    toast("Subject deleted.", "success");
    await loadSubjects();
  } catch {
    toast("Could not delete the subject. Please try again.", "error");
  }
}

/* ---------- Go ---------- */

loadSubjects();