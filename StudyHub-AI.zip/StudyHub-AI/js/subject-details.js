// Subject workspace: overview, notes, activities, materials, deadlines.

import { requireAuth } from "./auth-guard.js";
import { renderShell } from "./layout.js";

import {
  userCol,
  userDoc,
  safeColor,
  isValidId,
  toDate,
  shortDate,
  formatBytes
} from "./firestore.js";

import { el, icon, refreshIcons } from "./dom.js";

import {
  getDoc,
  getDocs,
  query,
  where,
  limit
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $ = (id) => document.getElementById(id);

/* ---------- Sign-in and page shell ---------- */

const user = await requireAuth();
renderShell(user, "subjects.html");

const subjectId = new URLSearchParams(location.search).get("id");
const detail = $("detail");

/* ---------- Small builders ---------- */

function showMessage(title, text) {
  detail.replaceChildren();

  const box = el("div", "card empty");
  box.append(el("h3", "", title), el("p", "", text));

  const back = el("a", "btn btn-primary", "Back to subjects");
  back.href = "subjects.html";
  back.style.marginTop = "16px";

  box.append(back);
  detail.append(box);
}

function emptyBox(title, text) {
  const box = el("div", "card empty");
  box.append(el("h3", "", title), el("p", "", text));
  return box;
}

function badge(text, kind) {
  return el("span", "badge badge-" + kind, text);
}

// One list row: a title, small grey details, and an optional badge
function row(title, parts, badgeEl) {
  const item = el("div", "list-item");
  const main = el("div", "list-main");

  main.append(el("div", "row-title", title));

  const meta = el("div", "row-meta");
  parts.filter(Boolean).forEach((p) => meta.append(el("span", "", p)));
  main.append(meta);

  item.append(main);
  if (badgeEl) item.append(badgeEl);

  return item;
}

const STATUS = {
  not_started: ["Not started", ""],
  in_progress: ["In progress", "warning"],
  completed: ["Completed", "success"]
};

const PRIORITY = { low: "Low", medium: "Medium", high: "High" };

/* =========================================
   LOAD THE SUBJECT
   ========================================= */

async function main() {
  if (!isValidId(subjectId)) {
    showMessage("Subject not found", "This link is not valid.");
    return;
  }

  let subject;

  try {
    // Only this user's own subjects can be read (enforced by Firestore rules)
    const snap = await getDoc(userDoc(user.uid, "subjects", subjectId));

    if (!snap.exists()) {
      showMessage("Subject not found", "It may have been deleted.");
      return;
    }

    subject = snap.data();
  } catch {
    showMessage("Could not load this subject", "Check your connection and try again.");
    return;
  }

  document.title = subject.name + " – StudyHub AI";

  // Notes and activities that belong to this subject
  const [notesRes, activitiesRes] = await Promise.allSettled([
    getDocs(query(
      userCol(user.uid, "notes"),
      where("subjectId", "==", subjectId),
      limit(100)
    )),
    getDocs(query(
      userCol(user.uid, "activities"),
      where("subjectId", "==", subjectId),
      limit(100)
    ))
  ]);

  const loadFailed =
    notesRes.status === "rejected" || activitiesRes.status === "rejected";

  const notes = notesRes.status === "fulfilled"
    ? notesRes.value.docs.map((d) => ({ id: d.id, ...d.data() }))
    : [];

  const activities = activitiesRes.status === "fulfilled"
    ? activitiesRes.value.docs.map((d) => ({ id: d.id, ...d.data() }))
    : [];

  // Newest notes first
  notes.sort((a, b) => (toDate(b.updatedAt) || 0) - (toDate(a.updatedAt) || 0));

  const materials = notes.flatMap((note) =>
    (Array.isArray(note.attachments) ? note.attachments : [])
      .map((file) => ({ ...file, noteTitle: note.title }))
  );

  const pending = activities.filter((a) => a.status !== "completed");
  const completed = activities.filter((a) => a.status === "completed");

  const deadlines = pending
    .filter((a) => toDate(a.deadline))
    .map((a) => ({ ...a, due: toDate(a.deadline) }))
    .sort((a, b) => a.due - b.due);

  const now = new Date();

  /* =========================================
     PANELS (one per tab)
     ========================================= */

  function overviewPanel() {
    const panel = el("div");

    if (loadFailed) {
      panel.append(el("p", "notice", "Some data could not be loaded. Refresh to try again."));
    }

    const nextDeadline = deadlines.find((a) => a.due >= now);

    const stats = [
      ["Notes", notes.length],
      ["Pending activities", pending.length],
      ["Completed", completed.length],
      ["Next deadline", nextDeadline ? shortDate(nextDeadline.due) : "None"]
    ];

    const grid = el("div", "mini-grid");
    stats.forEach(([label, value]) => {
      const card = el("div", "card stat");
      card.append(el("div", "stat-value", String(value)), el("div", "stat-label", label));
      grid.append(card);
    });

    const about = el("div", "card");
    about.append(
      el("h2", "", "About this subject"),
      el("p", subject.description ? "" : "muted",
         subject.description || "No description yet. Add one from the Subjects page.")
    );

    panel.append(grid, about);
    return panel;
  }

  function notesPanel() {
    if (notes.length === 0) {
      return emptyBox("No notes yet", "Notes for this subject will show up here.");
    }

    const card = el("div", "card");

    notes.forEach((note) => {
      const tags = Array.isArray(note.tags) ? note.tags.join(", ") : "";
      card.append(row(
        note.title,
        ["Updated " + shortDate(toDate(note.updatedAt)), tags],
        note.pinned ? badge("Pinned", "") : null
      ));
    });

    return card;
  }

  function activitiesPanel() {
    if (activities.length === 0) {
      return emptyBox("No activities yet", "Activities and assignments for this subject will show up here.");
    }

    const card = el("div", "card");

    activities.forEach((a) => {
      const due = toDate(a.deadline);
      const [label, kind] = STATUS[a.status] || STATUS.not_started;

      card.append(row(
        a.title,
        [
          due ? "Due " + shortDate(due) : "No deadline",
          (PRIORITY[a.priority] || "Medium") + " priority"
        ],
        badge(label, kind)
      ));
    });

    return card;
  }

  function materialsPanel() {
    if (materials.length === 0) {
      return emptyBox("No study materials yet", "Files attached to your notes will show up here.");
    }

    const card = el("div", "card");

    materials.forEach((file) => {
      card.append(row(
        file.name || "Untitled file",
        [formatBytes(file.size), "From: " + (file.noteTitle || "a note")]
      ));
    });

    return card;
  }

  function deadlinesPanel() {
    if (deadlines.length === 0) {
      return emptyBox("No deadlines", "Pending activities with a due date will show up here.");
    }

    const card = el("div", "card");

    deadlines.forEach((a) => {
      const isLate = a.due < now;
      card.append(row(
        a.title,
        ["Due " + shortDate(a.due)],
        isLate ? badge("Overdue", "danger") : null
      ));
    });

    return card;
  }

  /* =========================================
     PAGE: header + tabs + panel
     ========================================= */

  const TABS = [
    { key: "overview",   label: "Overview",                         build: overviewPanel },
    { key: "notes",      label: `Notes (${notes.length})`,          build: notesPanel },
    { key: "activities", label: `Activities (${activities.length})`, build: activitiesPanel },
    { key: "materials",  label: `Materials (${materials.length})`,  build: materialsPanel },
    { key: "deadlines",  label: `Deadlines (${deadlines.length})`,  build: deadlinesPanel }
  ];

  // Header
  const back = el("a", "back-link");
  back.href = "subjects.html";
  back.append(icon("arrow-left"), document.createTextNode("All subjects"));

  const head = el("div", "detail-head");
  head.style.setProperty("--subject-color", safeColor(subject.color));
  head.append(
    el("h1", "", subject.name),
    el("p", "muted", subject.description || "No description yet.")
  );

  // Tabs
  const tabBar = el("div", "tabs");
  tabBar.setAttribute("role", "tablist");

  const panel = el("div");
  panel.setAttribute("role", "tabpanel");

  const tabButtons = [];

  function selectTab(key) {
    tabButtons.forEach((button) => {
      button.setAttribute("aria-selected", String(button.dataset.key === key));
    });

    const tab = TABS.find((t) => t.key === key);
    panel.replaceChildren(tab.build());
  }

  TABS.forEach((tab) => {
    const button = el("button", "tab", tab.label);
    button.type = "button";
    button.setAttribute("role", "tab");
    button.dataset.key = tab.key;
    button.onclick = () => selectTab(tab.key);

    tabBar.append(button);
    tabButtons.push(button);
  });

  detail.replaceChildren(back, head, tabBar, panel);
  selectTab("overview");
  refreshIcons();
}

main();