// Uploading to Cloudinary with progress, plus time limits.
// Nothing here uses Firebase, so it is easy to test.

export class UploadError extends Error {}
export class TimeoutError extends Error {}

// Stops waiting after `ms` milliseconds
export function withTimeout(promise, ms) {
  let timer;

  const limit = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new TimeoutError("Timed out")), ms);
  });

  return Promise.race([promise, limit]).finally(() => clearTimeout(timer));
}

// Only links that point to YOUR Cloudinary account are trusted
export function isCloudinaryUrl(url, cloudName) {
  return (
    typeof url === "string" &&
    url.startsWith("https://res.cloudinary.com/" + cloudName + "/")
  );
}

// Uploads one file (unsigned, resource type "auto") and reports progress 0-100.
// It never waits forever:
//   - nothing moves for `stallMs` (15 s)        -> error
//   - file sent, no answer for `answerMs` (30 s) -> error
//   - the whole upload takes over `maxMs` (3 min) -> error
export function uploadToCloudinary(file, options) {
  const {
    cloudName,
    preset,
    onProgress,
    stallMs = 15000,
    answerMs = 30000,
    maxMs = 180000
  } = options;

  return new Promise((resolve, reject) => {
    if (!/^[A-Za-z0-9_-]+$/.test(cloudName || "") || !preset) {
      reject(new UploadError("Cloudinary is not set up. Check js/cloudinary-config.js."));
      return;
    }

    const xhr = new XMLHttpRequest();
    const form = new FormData();
    form.append("file", file);
    form.append("upload_preset", preset);

    let finished = false;
    let timer = null;
    const maxTimer = setTimeout(() => fail("The upload took too long. Tap Retry."), maxMs);

    function end() {
      finished = true;
      clearTimeout(timer);
      clearTimeout(maxTimer);
    }

    function fail(message) {
      if (finished) return;
      end();
      xhr.abort();
      reject(new UploadError(message));
    }

    function watch(ms, message) {
      clearTimeout(timer);
      timer = setTimeout(() => fail(message), ms);
    }

    const STALLED = "Upload timed out. Check your connection and tap Retry.";
    watch(stallMs, STALLED);

    // Every bit of progress restarts the 15 second clock
    xhr.upload.onprogress = (event) => {
      watch(stallMs, STALLED);

      if (event.lengthComputable && onProgress) {
        onProgress(Math.round((event.loaded / event.total) * 100));
      }
    };

    // The whole file was sent: now wait (a limited time) for Cloudinary's answer
    xhr.upload.onload = () => {
      watch(answerMs, "Cloudinary is taking too long to answer. Tap Retry.");
    };

    xhr.onerror = () => fail("No connection. Check your internet and tap Retry.");

    xhr.onload = () => {
      if (finished) return;

      let data = null;
      try {
        data = JSON.parse(xhr.responseText);
      } catch {}

      const ok = xhr.status >= 200 && xhr.status < 300 && data;

      if (ok && isCloudinaryUrl(data.secure_url, cloudName)) {
        end();
        resolve({
          url: data.secure_url,
          publicId: String(data.public_id || ""),
          resourceType: String(data.resource_type || "")
        });
        return;
      }

      const reason =
        data && data.error && data.error.message
          ? data.error.message
          : "unexpected answer (" + xhr.status + ")";

      // "Unknown API key" means Cloudinary did not accept the cloud name + preset
      // as an UNSIGNED upload (this code never sends an API key).
      const hint = /api key/i.test(reason)
        ? ' Check js/cloudinary-config.js: cloud "' + cloudName + '", preset "' + preset + '".'
        : "";

      fail('Cloudinary refused "' + file.name + '": ' + reason + "." + hint);
    };

    xhr.open("POST", "https://api.cloudinary.com/v1_1/" + cloudName + "/auto/upload");
    xhr.send(form);
  });
}