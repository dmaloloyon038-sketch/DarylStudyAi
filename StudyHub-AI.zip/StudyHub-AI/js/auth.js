// Authentication: Google and Facebook sign-in, and logout.

import { auth, db } from "./firebase-config.js";

import {
  signInWithPopup,
  GoogleAuthProvider,
  FacebookAuthProvider,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

import { initTheme, toast } from "./utils.js";

initTheme();

/* ---------- Setup ---------- */

const isAppPage = location.pathname.includes("/pages/");

const DASHBOARD = new URL(
  isAppPage ? "dashboard.html" : "pages/dashboard.html",
  location.href
).href;

const $ = (id) => document.getElementById(id);

// Friendly messages for Firebase error codes
const ERRORS = {
  "auth/account-exists-with-different-credential":
    "This email already has an account. Sign in with the method you used before (Google or Facebook).",
  "auth/popup-blocked":
    "Your browser blocked the sign-in window. Allow pop-ups and try again.",
  "auth/network-request-failed":
    "No connection. Check your internet and retry.",
  "auth/too-many-requests":
    "Too many attempts. Wait a few minutes and try again."
};

// These happen when the user simply closes the window: no error needed
const SILENT = ["auth/popup-closed-by-user", "auth/cancelled-popup-request"];

function errorMessage(err) {
  return ERRORS[err?.code] || "Something went wrong. Please try again.";
}

/* ---------- Logout (used by the dashboard) ---------- */

export async function logout() {
  await signOut(auth);

  const loginUrl = isAppPage ? "../login.html" : "login.html";
  location.href = new URL(loginUrl, location.href).href;
}

/* ---------- Skip the login page if already signed in ---------- */

let busy = false;

if (!isAppPage) {
  onAuthStateChanged(auth, (user) => {
    if (user && !busy) {
      location.replace(DASHBOARD); // the page guard handles the profile step
    }
  });
}

/* ---------- Google and Facebook sign-in ---------- */

async function signInWithSocial(provider, providerName, button) {
  const originalLabel = button.innerHTML;
  button.disabled = true;
  busy = true;

  try {
    // Opens the Google or Facebook window
    const { user } = await signInWithPopup(auth, provider);

    // First time here? Create the profile document.
    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);

    if (!snap.exists()) {
      await setDoc(ref, {
        uid: user.uid,
        fullName: user.displayName || "",
        nickname: "",
        email: user.email || "",
        photoURL: user.photoURL || "",
        provider: providerName,
        profileComplete: false,
        settings: { theme: "light", notifications: true },
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }

    // New users are sent to "Complete profile" by the page guard
    location.replace(DASHBOARD);
  } catch (err) {
    busy = false;
    button.disabled = false;
    button.innerHTML = originalLabel;

    if (!SILENT.includes(err?.code)) {
      toast(errorMessage(err), "error");
    }
  }
}

const googleBtn = $("google-btn");
if (googleBtn) {
  googleBtn.addEventListener("click", () => {
    signInWithSocial(new GoogleAuthProvider(), "google", googleBtn);
  });
}

const facebookBtn = $("facebook-btn");
if (facebookBtn) {
  facebookBtn.addEventListener("click", () => {
    signInWithSocial(new FacebookAuthProvider(), "facebook", facebookBtn);
  });
}