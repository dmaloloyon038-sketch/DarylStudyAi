// Activity rules that do not need the page or Firebase.
// Keeping them here makes them easy to test.

export const TITLE_MAX = 150;
export const DESC_MAX = 2000;
export const LINK_TITLE_MAX = 60;
export const LINK_URL_MAX = 500;

export const STATUSES = [
  { id: "not_started", label: "Not started" },
  { id: "in_progress", label: "In progress" },
  { id: "completed", label: "Completed" }
];

export const PRIORITIES = [
  { id: "low", label: "Low" },
  { id: "medium", label: "Medium" },
  { id: "high", label: "High" }
];

const PRIORITY_RANK = { high: 0, medium: 1, low: 2 };
const DAY = 24 * 60 * 60 * 1000;

export const statusLabel = (id) => (STATUSES.find((s) => s.id === id) || STATUSES[0]).label;
export const priorityLabel = (id) => (PRIORITIES.find((p) => p.id === id) || PRIORITIES[1]).label;

/* =========================================
   DATES
   ========================================= */

const pad = (n) => String(n).padStart(2, "0");
const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

// Date -> "2026-11-12T23:59" (what a date-time box needs)
export function toDateTimeLocal(date) {
  if (!date) return "";

  return (
    `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` +
    `T${pad(date.getHours())}:${pad(date.getMinutes())}`
  );
}

// "2026-11-12T23:59" -> Date.  Empty -> null.  Not a real date -> undefined.
export function fromDateTimeLocal(text) {
  const value = String(text || "").trim();
  if (!value) return null;

  const m = value.match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?$/);
  if (!m) return undefined;

  const year = Number(m[1]);
  const month = Number(m[2]);
  const day = Number(m[3]);
  const hour = m[4] === undefined ? 23 : Number(m[4]);
  const minute = m[5] === undefined ? 59 : Number(m[5]);

  if (year < 2000 || year > 2100 || hour > 23 || minute > 59) return undefined;

  const date = new Date(year, month - 1, day, hour, minute);

  // Reject dates that do not exist, like February 31
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
    return undefined;
  }

  return date;
}

const shortDay = (date) => date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
const shortTime = (date) => date.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });

/* =========================================
   LINKS
   ========================================= */

// Accepts any https web address. Refuses javascript:, http:, data: and so on.
export function parseWebLink(text) {
  const raw = String(text || "").trim();

  if (!raw) return { error: "Paste a link first." };
  if (raw.length > LINK_URL_MAX) return { error: "That link is too long." };

  // Allow "example.com/page" without https://
  const hasScheme = /^[a-z][a-z0-9+.-]*:/i.test(raw);

  let url;
  try {
    url = new URL(hasScheme ? raw : "https://" + raw);
  } catch {
    return { error: "That does not look like a link." };
  }

  if (url.protocol !== "https:") {
    return { error: "Use a link that starts with https://" };
  }

  if (url.username || url.password) return { error: "That link is not allowed." };
  if (!url.hostname.includes(".")) return { error: "That does not look like a web address." };
  if (url.href.length > LINK_URL_MAX) return { error: "That link is too long." };

  return { url: url.href };
}

/* =========================================
   CHECKS BEFORE SAVING
   ========================================= */

export function checkActivity({
  title,
  description,
  deadlineText,
  priority,
  status,
  linkTitle,
  linkUrlText
}) {
  const errors = {};
  const cleanTitle = String(title || "").trim().replace(/\s+/g, " ");
  const cleanDescription = String(description || "").trim();
  const deadline = fromDateTimeLocal(deadlineText);

  if (!cleanTitle) errors.title = "Please add a title.";
  else if (cleanTitle.length > TITLE_MAX) errors.title = `Keep the title under ${TITLE_MAX} characters.`;

  if (cleanDescription.length > DESC_MAX) {
    errors.description = `Keep the description under ${DESC_MAX} characters.`;
  }

  // The link: a title and a web address go together
  const cleanLinkTitle = String(linkTitle || "").trim().replace(/\s+/g, " ");
  const linkText = String(linkUrlText || "").trim();
  let linkUrl = "";

  if (linkText) {
    const parsed = parseWebLink(linkText);

    if (parsed.error) errors.linkUrl = parsed.error;
    else linkUrl = parsed.url;

    if (!cleanLinkTitle) errors.linkTitle = "Add a title for the link.";
  } else if (cleanLinkTitle) {
    errors.linkUrl = "Add the link address, or clear the link title.";
  }

  if (cleanLinkTitle.length > LINK_TITLE_MAX) {
    errors.linkTitle = `Keep the link title under ${LINK_TITLE_MAX} characters.`;
  }

  if (deadline === undefined) errors.deadline = "Enter a real date and time.";
  if (!PRIORITIES.some((p) => p.id === priority)) errors.priority = "Choose a priority.";
  if (!STATUSES.some((s) => s.id === status)) errors.status = "Choose a status.";

  return {
    errors,
    values: {
      title: cleanTitle,
      description: cleanDescription,
      deadline: deadline === undefined ? null : deadline,
      priority,
      status,
      linkTitle: linkUrl ? cleanLinkTitle : "",
      linkUrl
    }
  };
}

/* =========================================
   DEADLINES
   ========================================= */

export const isOverdue = (a, now) =>
  a.status !== "completed" && a.due instanceof Date && a.due < now;

// What to show next to a deadline.  kind: overdue | today | soon | later | done | none
export function dueInfo(a, now) {
  if (!(a.due instanceof Date)) return { kind: "none", text: "No deadline" };

  if (a.status === "completed") return { kind: "done", text: "Due " + shortDay(a.due) };

  if (a.due < now) {
    return { kind: "overdue", text: `Overdue · ${shortDay(a.due)}, ${shortTime(a.due)}` };
  }

  const days = Math.round((startOfDay(a.due) - startOfDay(now)) / DAY);

  if (days === 0) return { kind: "today", text: "Due today, " + shortTime(a.due) };
  if (days === 1) return { kind: "soon", text: "Due tomorrow, " + shortTime(a.due) };

  if (days < 7) {
    const weekday = a.due.toLocaleDateString(undefined, { weekday: "short" });
    return { kind: "soon", text: `Due ${weekday}, ${shortTime(a.due)}` };
  }

  return { kind: "later", text: `Due ${shortDay(a.due)}, ${shortTime(a.due)}` };
}

export function summarize(list, now) {
  const result = { pending: 0, overdue: 0, dueSoon: 0, completed: 0 };
  const weekEnd = now.getTime() + 7 * DAY;

  for (const a of list) {
    if (a.status === "completed") {
      result.completed++;
      continue;
    }

    result.pending++;

    if (a.due instanceof Date) {
      if (a.due < now) result.overdue++;
      else if (a.due.getTime() <= weekEnd) result.dueSoon++;
    }
  }

  return result;
}

// The next pending deadlines that are still ahead
export function upcoming(list, now, count = 5) {
  return list
    .filter((a) => a.status !== "completed" && a.due instanceof Date && a.due >= now)
    .sort((a, b) => a.due - b.due)
    .slice(0, count);
}

/* =========================================
   SEARCH, FILTER, SORT
   ========================================= */

export function searchTextFor(activity, subjectName) {
  const file = activity.attachment && activity.attachment.name;

  return [
    activity.title || "",
    activity.description || "",
    subjectName || "",
    activity.linkTitle || "",
    file || ""
  ]
    .join(" ")
    .toLowerCase();
}

export function filterActivities(list, filters) {
  const term = String(filters.term || "").trim().toLowerCase();
  const subject = filters.subject || "all";
  const status = filters.status || "all";
  const priority = filters.priority || "all";

  return list.filter((a) => {
    if (subject === "none" && a.subjectId) return false;
    if (subject !== "all" && subject !== "none" && a.subjectId !== subject) return false;
    if (status !== "all" && a.status !== status) return false;
    if (priority !== "all" && a.priority !== priority) return false;

    if (!term) return true;

    const text = a._search !== undefined ? a._search : searchTextFor(a, "");
    return text.includes(term);
  });
}

const compare = (x, y) => (x < y ? -1 : x > y ? 1 : 0);

// Pending first: soonest deadline first (overdue at the top), no deadline last,
// then high priority first. Completed ones go to the bottom, newest first.
export function sortActivities(list) {
  return [...list].sort((a, b) => {
    const aDone = a.status === "completed";
    const bDone = b.status === "completed";

    if (aDone !== bDone) return aDone ? 1 : -1;

    if (aDone) {
      return compare(b.updatedMs || 0, a.updatedMs || 0) || compare(a.title, b.title);
    }

    const aDue = a.due instanceof Date ? a.due.getTime() : Infinity;
    const bDue = b.due instanceof Date ? b.due.getTime() : Infinity;

    return (
      compare(aDue, bDue) ||
      compare(PRIORITY_RANK[a.priority] ?? 1, PRIORITY_RANK[b.priority] ?? 1) ||
      compare(a.title, b.title)
    );
  });
}

// The status before / after this one (for the board arrows)
export function neighborStatus(status, step) {
  const index = STATUSES.findIndex((s) => s.id === status);
  const target = STATUSES[index + step];
  return target ? target.id : null;
}