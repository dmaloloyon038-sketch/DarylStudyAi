// Checks files before they are uploaded.
// We look at the real content of each file, not just its name.

export const MAX_FILES = 10;
export const MAX_BYTES = 10 * 1024 * 1024;
export const ALLOWED_LABEL = "JPG, PNG, WEBP, PDF, DOCX or PPTX";

const DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation";

function extensionOf(name) {
  const dot = name.lastIndexOf(".");
  return dot === -1 ? "" : name.slice(dot + 1).toLowerCase();
}

function megabytes(bytes) {
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

// DOCX and PPTX are zip files. A real one lists a "word/" or "ppt/" folder.
async function zipHasFolder(file, folder) {
  const tail = await file.slice(-131072).arrayBuffer();
  const text = new TextDecoder("latin1").decode(tail);
  return text.includes(folder);
}

// Returns the real file type, or null if the file is not allowed
export async function detectType(file) {
  const head = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  const starts = (...bytes) => bytes.every((b, i) => head[i] === b);
  const ext = extensionOf(file.name);

  if (ext === "pdf" && starts(0x25, 0x50, 0x44, 0x46, 0x2d)) {
    return "application/pdf";
  }

  if (ext === "png" && starts(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a)) {
    return "image/png";
  }

  if ((ext === "jpg" || ext === "jpeg") && starts(0xff, 0xd8, 0xff)) {
    return "image/jpeg";
  }

  const isWebp =
    starts(0x52, 0x49, 0x46, 0x46) &&
    head[8] === 0x57 && head[9] === 0x45 && head[10] === 0x42 && head[11] === 0x50;
  if (ext === "webp" && isWebp) {
    return "image/webp";
  }

  // Zip files: only real DOCX and PPTX are allowed
  if (starts(0x50, 0x4b, 0x03, 0x04)) {
    if (ext === "docx" && (await zipHasFolder(file, "word/"))) return DOCX;
    if (ext === "pptx" && (await zipHasFolder(file, "ppt/"))) return PPTX;
    return null;
  }

  return null;
}

// Checks a batch of picked files.
// existingCount = files the note already has.
// Returns the files that are OK and a message for each one that is not.
export async function screenFiles(candidates, existingCount = 0) {
  const accepted = [];
  const rejected = [];

  for (const file of candidates) {
    if (existingCount + accepted.length >= MAX_FILES) {
      rejected.push(
        `"${file.name}" was not added. You can attach up to ${MAX_FILES} attachments per note.`
      );
      continue;
    }

    if (file.size === 0) {
      rejected.push(`"${file.name}" is empty.`);
      continue;
    }

    if (file.size > MAX_BYTES) {
      rejected.push(`File too big, max 10MB ("${file.name}" is ${megabytes(file.size)}).`);
      continue;
    }

    const type = await detectType(file);

    if (!type) {
      rejected.push(`"${file.name}" is not an allowed file. Use ${ALLOWED_LABEL}.`);
      continue;
    }

    accepted.push({ file, type });
  }

  return { accepted, rejected };
}