// "Complete your profile" page: saves full name + nickname.

import { auth, db } from "./firebase-config.js";
import { requireAuth } from "./auth-guard.js";
import { updateProfile } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

import {
  initTheme,
  toast,
  setLoading,
  fieldError
} from "./utils.js";

initTheme();

const $ = (id) => document.getElementById(id);

// Letters (any language), numbers, spaces and . _ - '
const NAME_PATTERN = /^[\p{L}\p{N} .'_-]+$/u;

// allowIncomplete lets users with an unfinished profile reach this page
const user = await requireAuth({ allowIncomplete: true });
const ref = doc(db, "users", user.uid);

let docExists = false;

/* ---------- Load existing data ---------- */

try {
  const snap = await getDoc(ref);
  docExists = snap.exists();
  const data = docExists ? snap.data() : {};

  // Already finished? Go straight to the dashboard.
  if (data.profileComplete === true) {
    location.replace("dashboard.html");
  }

  // Pre-fill the name that Google / Facebook gave us
  $("fullName").value = data.fullName || user.displayName || "";
} catch {
  $("fullName").value = user.displayName || "";
}

/* ---------- Save ---------- */

$("profile-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const fullName = $("fullName").value.trim().replace(/\s+/g, " ");
  const nickname = $("nickname").value.trim().replace(/\s+/g, " ");
  const button = $("submit");

  const fullNameOk =
    fullName.length >= 2 && fullName.length <= 60 && NAME_PATTERN.test(fullName);
  const nicknameOk =
    nickname.length >= 2 && nickname.length <= 30 && NAME_PATTERN.test(nickname);

  fieldError($("fullName"), fullNameOk ? "" : "Enter your full name (2–60 characters).");
  fieldError($("nickname"), nicknameOk ? "" : "Enter a nickname (2–30 characters).");

  if (!fullNameOk || !nicknameOk) return;

  setLoading(button, true);

  try {
    const profile = {
      uid: user.uid,
      fullName: fullName,
      nickname: nickname,
      email: user.email || "",
      photoURL: user.photoURL || "",
      profileComplete: true,
      updatedAt: serverTimestamp()
    };

    // Only set the creation date if the document is brand new
        // Only set these if the document is brand new
    if (!docExists) {
      const providerId = user.providerData[0]?.providerId;
      profile.provider = providerId === "facebook.com" ? "facebook" : "google";
      profile.settings = { theme: "light", notifications: true };
      profile.createdAt = serverTimestamp();
    }

    await setDoc(ref, profile, { merge: true });

    // The dashboard greets users by this name
    await updateProfile(auth.currentUser, { displayName: nickname });

    location.replace("dashboard.html");
  } catch {
    toast("Could not save your profile. Please try again.", "error");
    setLoading(button, false, "Continue to dashboard");
  }
});