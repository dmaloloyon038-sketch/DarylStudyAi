// Activities page: list view, board view, filters, add / edit / delete.

import { requireAuth } from "./auth-guard.js";
import { renderShell } from "./layout.js";
import { userCol, userDoc, safeColor, toDate } from "./firestore.js";
import { el, icon, refreshIcons } from "./dom.js";
import { toast, confirmModal, setLoading, fieldError } from "./utils.js";

import {
  STATUSES,
  PRIORITIES,
  statusLabel,
  priorityLabel,
  toDateTimeLocal,
  checkActivity,
  dueInfo,
  filterActivities,
  sortActivities,
  summarize,
  upcoming,
  searchTextFor,
  neighborStatus
} from "./activities-logic.js";

import {
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  serverTimestamp,
  Timestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $ = (id) => document.getElementById(id);

/* ---------- Sign-in and page shell ---------- */

const user = await requireAuth();
const uid = user.uid;
renderShell(user, "activities.html");

/* ---------- Never wait forever for a save ---------- */

const SAVE_TIMEOUT_MS = 15000;

class TimeoutError extends Error {}

function withTimeout(promise, ms) {
  let timer;

  const limitPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new TimeoutError("Timed out")), ms);
  });

  return Promise.race([promise, limitPromise]).finally(() => clearTimeout(timer));
}

/* ---------- State ---------- */

let activities = [];
let subjectsById = new Map();
let editing = null;     // the activity being edited (null = new)
let view = "list";      // "list" or "board"
let searchTimer = null;

const content = $("a-content");
const dialog = $("act-dialog");

/* =========================================
   SMALL BUILDERS
   ========================================= */

function addOption(select, value, label) {
  const option = document.createElement("option");
  option.value = value;
  option.textContent = label;
  select.append(option);
}

function emptyBox(title, text, buttonLabel, onClick) {
  const box = el("div", "card empty");
  box.append(el("h3", "", title), el("p", "", text));

  if (buttonLabel) {
    const button = el("button", "btn btn-primary", buttonLabel);
    button.type = "button";
    button.style.marginTop = "16px";
    button.onclick = onClick;
    box.append(button);
  }

  return box;
}

function iconButton(name, label, onClick) {
  const button = el("button", "icon-btn");
  button.type = "button";
  button.setAttribute("aria-label", label);
  button.append(icon(name));
  button.onclick = onClick;
  return button;
}

function subjectChip(activity) {
  const subject = subjectsById.get(activity.subjectId);
  if (!subject) return null;

  const chip = el("span", "act-chip", subject.name);
  chip.style.background = safeColor(subject.color);
  return chip;
}

function priorityBadge(activity) {
  const kind = { high: "danger", medium: "warning", low: "success" }[activity.priority] || "";
  return el("span", "badge badge-" + kind, priorityLabel(activity.priority));
}

// "Due tomorrow, 3:00 PM" with a red "Overdue" style when late
function dueLine(activity, now) {
  const info = dueInfo(activity, now);
  return el("span", "due due-" + info.kind, info.text);
}

/* =========================================
   LOAD
   ========================================= */

function fillSubjectSelects() {
  const filter = $("a-filter-subject");
  const picker = $("a-subject");
  const current = filter.value;

  filter.replaceChildren();
  picker.replaceChildren();

  addOption(filter, "all", "All subjects");
  addOption(filter, "none", "No subject");
  addOption(picker, "", "No subject");

  for (const [id, subject] of subjectsById) {
    addOption(filter, id, subject.name);
    addOption(picker, id, subject.name);
  }

  filter.value = subjectsById.has(current) || current === "none" ? current : "all";
}

function showSkeletons() {
  content.replaceChildren();

  for (let i = 0; i < 3; i++) {
    const box = el("div", "skeleton", "\u00a0");
    box.style.height = "84px";
    content.append(box);
  }
}

async function loadAll() {
  showSkeletons();

  try {
    const [subjectSnap, activitySnap] = await Promise.all([
      getDocs(query(userCol(uid, "subjects"), orderBy("name"), limit(200))),
      getDocs(query(userCol(uid, "activities"), orderBy("createdAt", "desc"), limit(500)))
    ]);

    subjectsById = new Map(subjectSnap.docs.map((d) => [d.id, d.data()]));

    activities = activitySnap.docs.map((d) => {
      const data = d.data();
      const updated = toDate(data.updatedAt);

      const activity = { id: d.id, ...data, due: toDate(data.deadline) };
      activity.updatedMs = updated ? updated.getTime() : 0;
      activity._search = searchTextFor(activity, subjectsById.get(data.subjectId)?.name);
      return activity;
    });

    fillSubjectSelects();
    render();
  } catch {
    content.replaceChildren();

    const box = emptyBox(
      "Could not load activities",
      "Check your connection and try again.",
      "Try again",
      loadAll
    );
    content.append(box);
  }
}

/* =========================================
   SHOW
   ========================================= */

function statCard(label, value, alert) {
  const card = el("div", "card stat");
  const number = el("div", "stat-value", String(value));
  if (alert) number.classList.add("alert");

  card.append(number, el("div", "stat-label", label));
  return card;
}

function renderStats(now) {
  const s = summarize(activities, now);
  const box = $("a-stats");

  box.replaceChildren(
    statCard("Pending", s.pending),
    statCard("Overdue", s.overdue, s.overdue > 0),
    statCard("Due this week", s.dueSoon),
    statCard("Completed", s.completed)
  );
}

function renderUpcoming(now) {
  const box = $("a-upcoming");
  box.replaceChildren();

  const next = upcoming(activities, now, 5);

  if (next.length === 0) {
    const empty = el("div", "empty small");
    empty.append(el("p", "", "No upcoming deadlines. Add a deadline to an activity to see it here."));
    box.append(empty);
    return;
  }

  next.forEach((a) => {
    const row = el("div", "list-item");

    const dot = el("span", "dot");
    const subject = subjectsById.get(a.subjectId);
    dot.style.background = safeColor(subject ? subject.color : "");

    const main = el("div", "list-main");
    main.append(el("div", "row-title", a.title));

    const meta = el("div", "row-meta");
    meta.append(dueLine(a, now));
    main.append(meta);

    row.append(dot, main, priorityBadge(a));
    box.append(row);
  });
}

// The round button that marks an activity done (or not done)
function doneButton(a) {
  const done = a.status === "completed";

  const button = el("button", "done-btn");
  button.type = "button";
  button.setAttribute("aria-pressed", String(done));
  button.setAttribute(
    "aria-label",
    (done ? "Mark as not done: " : "Mark as completed: ") + a.title
  );
  button.append(icon(done ? "circle-check" : "circle"));
  button.onclick = () => setStatus(a, done ? "not_started" : "completed", button);

  return button;
}

function actions(a) {
  const box = el("div", "act-actions");
  box.append(
    iconButton("pencil", "Edit " + a.title, () => openDialog(a)),
    iconButton("trash-2", "Delete " + a.title, () => removeActivity(a))
  );
  return box;
}

function metaLine(a, now) {
  const meta = el("div", "act-meta");

  const chip = subjectChip(a);
  if (chip) meta.append(chip);

  meta.append(dueLine(a, now));

  if (a.status === "in_progress") meta.append(el("span", "badge", "In progress"));

  return meta;
}

function activityRow(a, now) {
  const row = el("article", "card act-row");
  if (a.status === "completed") row.classList.add("is-done");

  const main = el("div", "act-main");
  main.append(el("div", "act-title", a.title));
  if (a.description) main.append(el("p", "muted act-desc", a.description));
  main.append(metaLine(a, now));

  row.append(doneButton(a), main, priorityBadge(a), actions(a));
  return row;
}

function boardCard(a, now) {
  const card = el("article", "card act-card");
  if (a.status === "completed") card.classList.add("is-done");

  card.append(el("div", "act-title", a.title));
  card.append(metaLine(a, now));

  const foot = el("div", "act-card-foot");
  foot.append(priorityBadge(a));

  const moves = el("div", "act-actions");
  const back = neighborStatus(a.status, -1);
  const next = neighborStatus(a.status, 1);

  if (back) moves.append(iconButton("chevron-left", "Move to " + statusLabel(back), () => setStatus(a, back)));
  if (next) moves.append(iconButton("chevron-right", "Move to " + statusLabel(next), () => setStatus(a, next)));

  moves.append(
    iconButton("pencil", "Edit " + a.title, () => openDialog(a)),
    iconButton("trash-2", "Delete " + a.title, () => removeActivity(a))
  );

  foot.append(moves);
  card.append(foot);
  return card;
}

function boardView(list, now) {
  const wrap = el("div", "board");

  for (const status of STATUSES) {
    const items = list.filter((a) => a.status === status.id);

    const column = el("section", "board-col");
    column.append(el("h3", "board-title", `${status.label} (${items.length})`));

    if (items.length === 0) column.append(el("p", "muted", "Nothing here."));
    items.forEach((a) => column.append(boardCard(a, now)));

    wrap.append(column);
  }

  return wrap;
}

function render() {
  const now = new Date();

  const filters = {
    term: $("a-search").value,
    subject: $("a-filter-subject").value,
    status: view === "board" ? "all" : $("a-filter-status").value,
    priority: $("a-filter-priority").value
  };

  renderStats(now);
  renderUpcoming(now);

  const visible = sortActivities(filterActivities(activities, filters));

  content.replaceChildren();

  if (visible.length === 0) {
    const nothingYet =
      activities.length === 0 &&
      !filters.term.trim() &&
      filters.subject === "all" &&
      filters.status === "all" &&
      filters.priority === "all";

    content.append(
      nothingYet
        ? emptyBox(
            "No activities yet",
            "Add your first assignment or task to start tracking deadlines.",
            "Add activity",
            () => openDialog()
          )
        : emptyBox("No activities found", "Try a different search or filter.")
    );
  } else if (view === "list") {
    visible.forEach((a) => content.append(activityRow(a, now)));
  } else {
    content.append(boardView(visible, now));
  }

  refreshIcons();
}

/* ----- Filters and view switch ----- */

function setView(next) {
  view = next;

  $("view-list").setAttribute("aria-selected", String(next === "list"));
  $("view-board").setAttribute("aria-selected", String(next === "board"));
  $("a-filter-status").disabled = next === "board";

  render();
}

$("view-list").addEventListener("click", () => setView("list"));
$("view-board").addEventListener("click", () => setView("board"));

$("a-search").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(render, 200);
});

["a-filter-subject", "a-filter-status", "a-filter-priority"].forEach((id) => {
  $(id).addEventListener("change", render);
});

/* =========================================
   QUICK STATUS CHANGE
   ========================================= */

async function setStatus(activity, status, button) {
  if (activity.status === status) return;
  if (button) button.disabled = true;

  try {
    await withTimeout(
      updateDoc(userDoc(uid, "activities", activity.id), {
        status: status,
        updatedAt: serverTimestamp()
      }),
      SAVE_TIMEOUT_MS
    );

    activity.status = status;
    activity.updatedMs = Date.now();
    render();
  } catch {
    toast("Could not update the activity. Please try again.", "error");
    if (button) button.disabled = false;
  }
}

/* =========================================
   ADD / EDIT
   ========================================= */

function openDialog(activity) {
  editing = activity || null;

  $("act-title").textContent = activity ? "Edit activity" : "Add activity";
  $("a-title").value = activity ? activity.title : "";
  $("a-subject").value = activity && subjectsById.has(activity.subjectId) ? activity.subjectId : "";
  $("a-desc").value = activity ? activity.description || "" : "";
  $("a-deadline").value = activity ? toDateTimeLocal(activity.due) : "";
  $("a-link-title").value = activity ? activity.linkTitle || "" : "";
  $("a-link-url").value = activity ? activity.linkUrl || "" : "";
  $("a-priority").value = activity ? activity.priority : "medium";
  $("a-status").value = activity ? activity.status : "not_started";

  ["a-title", "a-desc", "a-deadline", "a-link-title", "a-link-url"].forEach((id) => fieldError($(id), ""));

  dialog.showModal();
  $("a-title").focus();
}

$("add-btn").addEventListener("click", () => openDialog());
$("a-cancel").addEventListener("click", () => dialog.close());
$("a-clear-deadline").addEventListener("click", () => {
  $("a-deadline").value = "";
});

$("act-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const button = $("a-save");

  const { errors, values } = checkActivity({
    title: $("a-title").value,
    description: $("a-desc").value,
    deadlineText: $("a-deadline").value,
    priority: $("a-priority").value,
    status: $("a-status").value,
    linkTitle: $("a-link-title").value,
    linkUrlText: $("a-link-url").value
  });

  fieldError($("a-title"), errors.title || "");
  fieldError($("a-desc"), errors.description || "");
  fieldError($("a-deadline"), errors.deadline || "");
  fieldError($("a-link-title"), errors.linkTitle || "");
  fieldError($("a-link-url"), errors.linkUrl || "");

  if (Object.keys(errors).length > 0) return;

  setLoading(button, true);

  const fields = {
    subjectId: $("a-subject").value,
    title: values.title,
    description: values.description,
    deadline: values.deadline ? Timestamp.fromDate(values.deadline) : null,
    priority: values.priority,
    status: values.status,
    linkTitle: values.linkTitle,
    linkUrl: values.linkUrl,
    updatedAt: serverTimestamp()
  };

  try {
    if (editing) {
      await withTimeout(updateDoc(userDoc(uid, "activities", editing.id), fields), SAVE_TIMEOUT_MS);
    } else {
      await withTimeout(
        addDoc(userCol(uid, "activities"), {
          ownerId: uid,
          ...fields,
          createdAt: serverTimestamp()
        }),
        SAVE_TIMEOUT_MS
      );
    }

    const wasEditing = editing !== null;
    dialog.close();
    toast(wasEditing ? "Activity updated." : "Activity added.", "success");
    await loadAll();
  } catch (err) {
    toast(
      err instanceof TimeoutError
        ? "Saving is taking too long. Check your connection and try again."
        : "Could not save the activity. Please try again.",
      "error",
      6000
    );
  }

  setLoading(button, false, "Save activity");
});

/* =========================================
   DELETE (asks "Are you sure?" first)
   ========================================= */

async function removeActivity(activity) {
  const confirmed = await confirmModal({
    title: "Are you sure?",
    message: `Delete "${activity.title}"? This cannot be undone.`,
    confirmText: "Yes, delete",
    danger: true
  });

  if (!confirmed) return;

  try {
    await withTimeout(deleteDoc(userDoc(uid, "activities", activity.id)), SAVE_TIMEOUT_MS);
    toast("Activity deleted.", "success");
    await loadAll();
  } catch {
    toast("Could not delete the activity. Please try again.", "error");
  }
}

/* ---------- Set up the fixed choices, then load ---------- */

addOption($("a-filter-status"), "all", "All statuses");
STATUSES.forEach((s) => {
  addOption($("a-filter-status"), s.id, s.label);
  addOption($("a-status"), s.id, s.label);
});

addOption($("a-filter-priority"), "all", "All priorities");
PRIORITIES.forEach((p) => {
  addOption($("a-filter-priority"), p.id, p.label);
  addOption($("a-priority"), p.id, p.label);
});

loadAll();
