// Shared helpers: theme, toasts, confirm modal, validation.

/* ---------- Theme (light / dark) ---------- */

export function initTheme() {
  let theme = "light";

  try {
    const saved = localStorage.getItem("sh-theme");
    const prefersDark = matchMedia("(prefers-color-scheme: dark)").matches;
    theme = saved || (prefersDark ? "dark" : "light");
  } catch {}

  document.documentElement.dataset.theme = theme;
}

export function toggleTheme() {
  const current = document.documentElement.dataset.theme;
  const next = current === "dark" ? "light" : "dark";

  document.documentElement.dataset.theme = next;

  try {
    localStorage.setItem("sh-theme", next);
  } catch {}
}

/* ---------- Safe text ---------- */

export function escapeHTML(text) {
  const map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  return String(text).replace(/[&<>"']/g, (c) => map[c]);
}

/* ---------- Toast notification ---------- */

export function toast(message, type = "info", ms = 4000) {
  let box = document.getElementById("toasts");

  if (!box) {
    box = document.createElement("div");
    box.id = "toasts";
    box.setAttribute("role", "status");
    box.setAttribute("aria-live", "polite");
  }

  // An open pop-up window sits above everything, so show the toast inside it
  const host = document.querySelector("dialog[open]") || document.body;
  if (box.parentNode !== host) host.append(box);

  const el = document.createElement("div");
  el.className = "toast " + type;
  el.textContent = message; // textContent is safe from XSS

  box.append(el);
  setTimeout(() => el.remove(), ms);
}

/* ---------- Confirmation modal ---------- */

export function confirmModal({ title, message, confirmText = "Confirm", danger = false }) {
  return new Promise((resolve) => {
    const back = document.createElement("div");
    back.className = "modal-back";

    const modal = document.createElement("div");
    modal.className = "modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");

    const heading = document.createElement("h2");
    heading.textContent = title;

    const text = document.createElement("p");
    text.textContent = message;

    const actions = document.createElement("div");
    actions.className = "actions";

    const cancelBtn = document.createElement("button");
    cancelBtn.className = "btn btn-ghost";
    cancelBtn.textContent = "Cancel";

    const okBtn = document.createElement("button");
    okBtn.className = "btn " + (danger ? "btn-danger" : "btn-primary");
    okBtn.textContent = confirmText;

    const finish = (answer) => {
      back.remove();
      resolve(answer);
    };

    cancelBtn.onclick = () => finish(false);
    okBtn.onclick = () => finish(true);
    back.onclick = (e) => {
      if (e.target === back) finish(false);
    };

    actions.append(cancelBtn, okBtn);
    modal.append(heading, text, actions);
    back.append(modal);
    document.body.append(back);
    okBtn.focus();
  });
}

/* ---------- Validation ---------- */

export function isEmail(value) {
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  return pattern.test(value) && value.length <= 254;
}

export function passwordIssues(password) {
  const issues = [];

  if (password.length < 8) {
    issues.push("at least 8 characters");
  }
  if (!/[a-z]/.test(password) || !/[A-Z]/.test(password)) {
    issues.push("upper and lower case letters");
  }
  if (!/\d/.test(password)) {
    issues.push("a number");
  }

  return issues;
}

/* ---------- Form helpers ---------- */

export function setLoading(button, isLoading, label) {
  button.disabled = isLoading;
  button.replaceChildren();

  if (isLoading) {
    const spinner = document.createElement("span");
    spinner.className = "spinner";
    button.append(spinner, " Please wait…");
  } else {
    button.textContent = label;
  }
}

export function fieldError(input, message) {
  input.setAttribute("aria-invalid", message ? "true" : "false");

  const errorEl = document.getElementById(input.id + "-error");
  if (errorEl) {
    errorEl.textContent = message || "";
  }
}

/* ---------- Dates ---------- */

export function formatDate(date) {
  return date.toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric"
  });
}