// Builds the sidebar and top bar for app pages.
// Pages that are not built yet show a "Soon" tag and cannot be clicked.

import { logout } from "./auth.js";
import { toggleTheme, initTheme, formatDate } from "./utils.js";

// [file, icon, label, isBuilt]
const NAV = [
  ["dashboard.html",     "layout-dashboard",     "Dashboard",     true],
  ["subjects.html",      "book-open",            "Subjects",      true],
  ["notes.html",         "notebook-pen",         "Notes",         true],
  ["activities.html",    "list-checks",          "Activities",    true],
  ["calendar.html",      "calendar-days",        "Calendar",      true],
  ["ai-assistant.html",  "sparkles",             "AI Assistant",  false],
  ["flashcards.html",    "layers",               "Flashcards",    false],
  ["quizzes.html",       "circle-help",          "Quizzes",       false],
  ["study-planner.html", "timer",                "Study Planner", false],
  ["analytics.html",     "chart-no-axes-column", "Analytics",     false],
  ["settings.html",      "settings",             "Settings",      false]
  
];

export function renderShell(user, activePage) {
  initTheme();

  /* ----- Sidebar links ----- */
  const links = NAV.map(([href, icon, label, isBuilt]) => {
    if (isBuilt) {
      const current = href === activePage ? 'aria-current="page"' : "";
      return `
        <a href="${href}" ${current}>
          <i data-lucide="${icon}"></i>
          <span class="label">${label}</span>
        </a>`;
    }
    return `
      <span class="soon" aria-disabled="true">
        <i data-lucide="${icon}"></i>
        <span class="label">${label}</span>
        <span class="tag">Soon</span>
      </span>`;
  }).join("");

  document.getElementById("sidebar").innerHTML = `
    <div class="brand">
      <span class="brand-mark">S</span>
      <span class="name">StudyHub AI</span>
    </div>
    <nav class="nav" aria-label="Main">${links}</nav>`;

  /* ----- Top bar ----- */
  document.getElementById("topbar").innerHTML = `
    <button class="icon-btn" id="menu" aria-label="Toggle navigation">
      <i data-lucide="menu"></i>
    </button>
    <span class="grow"></span>
    <button class="icon-btn" id="theme" aria-label="Toggle dark mode">
      <i data-lucide="moon"></i>
    </button>
    <button class="btn btn-ghost" id="logout">
      <i data-lucide="log-out"></i>
      <span class="desktop-only">Log out</span>
    </button>
    <span class="avatar" id="avatar" aria-hidden="true"></span>`;

  // First letter of the user's name (set safely with textContent)
  const nameOrEmail = (user.displayName || user.email || "?").trim();
  document.getElementById("avatar").textContent = nameOrEmail[0].toUpperCase();

  /* ----- Restore collapsed sidebar ----- */
  try {
    if (localStorage.getItem("sh-collapsed") === "1") {
      document.body.classList.add("collapsed");
    }
  } catch {}

  /* ----- Button actions ----- */
  document.getElementById("menu").onclick = () => {
    const isMobile = matchMedia("(max-width: 900px)").matches;

    if (isMobile) {
      document.body.classList.toggle("nav-open");
    } else {
      const collapsed = document.body.classList.toggle("collapsed");
      try {
        localStorage.setItem("sh-collapsed", collapsed ? "1" : "0");
      } catch {}
    }
  };

  document.querySelector(".backdrop").onclick = () => {
    document.body.classList.remove("nav-open");
  };

  document.getElementById("theme").onclick = toggleTheme;
  document.getElementById("logout").onclick = logout;

  // Draw the Lucide icons
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

/* ---------- Welcome message ---------- */

export function greeting(user) {
  const hour = new Date().getHours();

  let part = "Good evening";
  if (hour < 12) part = "Good morning";
  else if (hour < 18) part = "Good afternoon";

  const firstName = (user.displayName || "student").split(" ")[0];

  return {
    title: `${part}, ${firstName}`,
    date: formatDate(new Date())
  };
}