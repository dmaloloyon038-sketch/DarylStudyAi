// Shows note text with a tiny, safe set of rules:
//   "# Title"   -> heading
//   "## Title"  -> smaller heading
//   "- item"    -> bullet
// The space after # or - is required. "#Title" stays normal text.
// Text is added with textContent, so nothing typed can run as code.

import { el } from "./dom.js";

export function renderContent(text) {
  const box = el("div", "note-content");
  const parts = document.createDocumentFragment();

  let list = null;
  let lastWasGap = false;

  for (const raw of text.split("\n")) {
    const line = raw.replace(/\s+$/, "");

    // Blank line: one small gap (several blank lines count as one)
    if (line === "") {
      list = null;
      if (!lastWasGap) parts.append(el("div", "note-gap"));
      lastWasGap = true;
      continue;
    }
    lastWasGap = false;

    // Bullet
    const bullet = line.match(/^\s*- +(\S.*)$/);
    if (bullet) {
      if (!list) {
        list = el("ul");
        parts.append(list);
      }
      list.append(el("li", "", bullet[1]));
      continue;
    }
    list = null;

    // Headings
    const small = line.match(/^## +(\S.*)$/);
    const big = line.match(/^# +(\S.*)$/);

    if (small) parts.append(el("h4", "", small[1]));
    else if (big) parts.append(el("h3", "", big[1]));
    else parts.append(el("p", "", line));
  }

  box.append(parts);
  return box;
}