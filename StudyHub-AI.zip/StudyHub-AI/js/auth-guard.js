// Protects app pages:
// 1. Signed-out visitors go to the login page.
// 2. Users with an unfinished profile go to "Complete profile".
//
// This is only for convenience. Real protection comes from
// Firestore and Storage security rules.

import { auth, db } from "./firebase-config.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

export function requireAuth({ allowIncomplete = false } = {}) {
  return new Promise((resolve) => {
    onAuthStateChanged(auth, async (user) => {

      // 1. Not signed in
      if (!user) {
        location.replace(new URL("../login.html", location.href).href);
        return;
      }

      // 2. Profile not finished
      if (!allowIncomplete) {
        let complete = false;

        try {
          const snap = await getDoc(doc(db, "users", user.uid));
          complete = snap.exists() && snap.data().profileComplete === true;
        } catch {
          complete = false;
        }

        if (!complete) {
          location.replace("complete-profile.html");
          return;
        }
      }

      resolve(user);
    });
  });
}