export const CLOUDINARY_CLOUD_NAME = "rafkkdvw";
export const CLOUDINARY_UPLOAD_PRESET = "studyhub-notes";