// Note rules that do not need the page or Firebase.
// Keeping them here makes them easy to test.

export const TITLE_MAX = 150;
export const CONTENT_MAX = 100000;

/* ---------- Topics and tags ---------- */

// Turns "a, b, #c" into ["a", "b", "c"] and checks the limits
export function parseList(text, maxItems, maxLength, label) {
  const seen = new Set();
  const items = [];

  for (const part of text.split(",")) {
    const item = part.trim().replace(/\s+/g, " ").replace(/^#/, "");
    if (!item) continue;

    if (item.length > maxLength) {
      return { error: `Each ${label} must be ${maxLength} characters or fewer.` };
    }

    const key = item.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      items.push(item);
    }
  }

  if (items.length > maxItems) {
    return { error: `Use ${maxItems} ${label}s or fewer.` };
  }

  return { items };
}

/* ---------- Checks before saving ---------- */

export function checkNote(title, content) {
  const errors = {};
  const cleanTitle = title.trim();

  if (cleanTitle.length < 1) {
    errors.title = "Please add a title before saving.";
  } else if (cleanTitle.length > TITLE_MAX) {
    errors.title = `Keep the title under ${TITLE_MAX} characters.`;
  }

  if (content.length > CONTENT_MAX) {
    errors.content =
      `This note is too long (${content.length.toLocaleString()} of ` +
      `${CONTENT_MAX.toLocaleString()} characters).`;
  }

  return errors;
}

/* ---------- Word count ---------- */

export function countWords(text) {
  const words = text.match(/\S+/g);
  return words ? words.length : 0;
}

export function wordLabel(count) {
  return count + (count === 1 ? " word" : " words");
}

/* ---------- Search, filter and sort ---------- */

// Everything searchable, in lower case (worked out once per note)
export function searchTextFor(note) {
  return [
    note.title || "",
    note.content || "",
    ...(note.topics || []),
    ...(note.tags || [])
  ].join(" ").toLowerCase();
}

export function filterNotes(notes, term, subjectFilter) {
  const needle = term.trim().toLowerCase();

  return notes.filter((note) => {
    if (subjectFilter === "none" && note.subjectId) return false;

    if (
      subjectFilter !== "all" &&
      subjectFilter !== "none" &&
      note.subjectId !== subjectFilter
    ) {
      return false;
    }

    if (!needle) return true;

    const text = note._search !== undefined ? note._search : searchTextFor(note);
    return text.includes(needle);
  });
}

function updatedMillis(note) {
  const time = note.updatedAt;
  return time && typeof time.toMillis === "function" ? time.toMillis() : 0;
}

// Pinned notes first, then newest first
export function sortNotes(notes) {
  return [...notes].sort((a, b) => {
    if (Boolean(a.pinned) !== Boolean(b.pinned)) return a.pinned ? -1 : 1;
    return updatedMillis(b) - updatedMillis(a);
  });
}

/* ---------- Download as .txt ---------- */

export function noteToText(note, subjectName) {
  const lines = [note.title, ""];

  if (subjectName) lines.push("Subject: " + subjectName);
  if (note.topics && note.topics.length) lines.push("Topics: " + note.topics.join(", "));
  if (note.tags && note.tags.length) lines.push("Tags: " + note.tags.map((t) => "#" + t).join(" "));
  if (lines.length > 2) lines.push("");

  lines.push(note.content || "");
  return lines.join("\n");
}

export function safeFileName(title) {
  const base = String(title || "")
    .replace(/[^\p{L}\p{N} _-]/gu, "_")
    .trim()
    .slice(0, 60);

  return (base || "note") + ".txt";
}