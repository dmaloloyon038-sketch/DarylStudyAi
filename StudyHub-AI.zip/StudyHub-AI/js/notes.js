// Notes page: list, search, filter, create, edit, pin, delete,
// Edit/Preview, draft auto-save, word count, download, attachments.
// Attachments: files are uploaded to Cloudinary (not Firebase Storage),
// links (Canva, Google Drive, YouTube) are saved with the note.
// The text is saved FIRST. Files upload after, in the background.

import { requireAuth } from "./auth-guard.js";
import { renderShell } from "./layout.js";

import {
  userCol,
  userDoc,
  safeColor,
  isValidId,
  toDate,
  shortDate,
  formatBytes
} from "./firestore.js";

import { el, icon, refreshIcons } from "./dom.js";
import { toast, confirmModal, setLoading, fieldError } from "./utils.js";
import { renderContent } from "./markdown.js";

import {
  CONTENT_MAX,
  parseList,
  checkNote,
  countWords,
  wordLabel,
  searchTextFor,
  filterNotes,
  sortNotes,
  noteToText,
  safeFileName
} from "./notes-logic.js";

import { MAX_FILES, screenFiles } from "./file-check.js";
import { parseLink, serviceLabel } from "./links.js";

import {
  CLOUDINARY_CLOUD_NAME,
  CLOUDINARY_UPLOAD_PRESET
} from "./cloudinary-config.js";

import {
  UploadError,
  TimeoutError,
  withTimeout,
  uploadToCloudinary,
  isCloudinaryUrl as isUrlFromCloud
} from "./upload.js";

import {
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
  arrayUnion,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $ = (id) => document.getElementById(id);

/* ---------- Sign-in and page shell ---------- */

const user = await requireAuth();
const uid = user.uid;
renderShell(user, "notes.html");

/* ---------- Settings ---------- */

const DRAFT_EVERY_MS = 2000;
const SAVE_TIMEOUT_MS = 15000;  // saving the text never waits longer than this

/* ---------- State ---------- */

let notes = [];
let subjectsById = new Map();

let editing = null;     // the note being edited (null = new note)
let keptFiles = [];     // attachments the note already has and keeps
let pending = [];       // new files waiting for Save: { file, type }

let searchTimer = null;
let countTimer = null;
let draftTimer = null;
let lastSnapshot = "";  // last saved (or loaded) form values

const grid = $("note-grid");
const editorDialog = $("editor-dialog");
const viewDialog = $("view-dialog");

/* =========================================
   CLOUDINARY LINKS
   ========================================= */

// Only links that point to YOUR Cloudinary account are trusted
const isCloudinaryUrl = (url) => isUrlFromCloud(url, CLOUDINARY_CLOUD_NAME);

/* =========================================
   SMALL HELPERS
   ========================================= */

function chipRow(topics, tags) {
  const row = el("div", "chips");
  (topics || []).forEach((t) => row.append(el("span", "chip-sm topic", t)));
  (tags || []).forEach((t) => row.append(el("span", "chip-sm", "#" + t)));
  return row;
}

function subjectChip(note) {
  const subject = subjectsById.get(note.subjectId);
  if (!subject) return null;

  const chip = el("span", "chip-sm", subject.name);
  chip.style.background = safeColor(subject.color);
  chip.style.color = "#252438";
  return chip;
}

function emptyBox(title, text, buttonLabel, onClick) {
  const box = el("div", "card empty");
  box.append(el("h3", "", title), el("p", "", text));

  if (buttonLabel) {
    const button = el("button", "btn btn-primary", buttonLabel);
    button.type = "button";
    button.style.marginTop = "16px";
    button.onclick = onClick;
    box.append(button);
  }

  return box;
}

// Saves text as a .txt file on the device
function downloadText(fileName, text) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.append(link);
  link.click();
  link.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* =========================================
   LOAD AND SHOW NOTES
   ========================================= */

function showSkeletons() {
  grid.replaceChildren();

  for (let i = 0; i < 3; i++) {
    const box = el("div", "skeleton", "\u00a0");
    box.style.height = "140px";
    grid.append(box);
  }
}

function fillSubjectSelects() {
  const filter = $("filter-subject");
  const picker = $("n-subject");

  filter.replaceChildren();
  picker.replaceChildren();

  const addOption = (select, value, label) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label;
    select.append(option);
  };

  addOption(filter, "all", "All subjects");
  addOption(filter, "none", "No subject");
  addOption(picker, "", "No subject");

  for (const [id, subject] of subjectsById) {
    addOption(filter, id, subject.name);
    addOption(picker, id, subject.name);
  }
}

async function loadAll() {
  showSkeletons();

  try {
    const [subjectSnap, noteSnap] = await Promise.all([
      getDocs(query(userCol(uid, "subjects"), orderBy("name"), limit(200))),
      getDocs(query(userCol(uid, "notes"), orderBy("updatedAt", "desc"), limit(300)))
    ]);

    subjectsById = new Map(subjectSnap.docs.map((d) => [d.id, d.data()]));

    notes = noteSnap.docs.map((d) => {
      const note = { id: d.id, ...d.data() };
      note._search = searchTextFor(note); // worked out once so searching stays fast
      return note;
    });

    const current = $("filter-subject").value;
    fillSubjectSelects();

    // Keep the filter, or use ?subject=ID from the address
    const wanted = new URLSearchParams(location.search).get("subject");
    if (current) $("filter-subject").value = current;
    else if (isValidId(wanted) && subjectsById.has(wanted)) $("filter-subject").value = wanted;

    render();
  } catch {
    grid.replaceChildren();

    const box = el("div", "card empty");
    box.append(
      el("h3", "", "Could not load notes"),
      el("p", "", "Check your connection and try again.")
    );

    const retry = el("button", "btn btn-primary", "Try again");
    retry.type = "button";
    retry.style.marginTop = "16px";
    retry.onclick = loadAll;

    box.append(retry);
    grid.append(box);
  }
}

function noteCard(note) {
  const card = el("article", "card note-card");
  const subject = subjectsById.get(note.subjectId);
  if (subject) card.style.setProperty("--subject-color", safeColor(subject.color));

  const titleRow = el("div", "note-title-row");
  const openBtn = el("button", "note-open", note.title);
  openBtn.type = "button";
  titleRow.append(openBtn);

  if (note.pinned) {
    const pin = icon("pin");
    pin.classList.add("pin-icon");
    pin.setAttribute("aria-label", "Pinned");
    titleRow.append(pin);
  }

  card.append(titleRow);

  // Only the start of the text is used, so very long notes stay fast
  const snippet = (note.content || "").slice(0, 600).replace(/\s+/g, " ").trim().slice(0, 160);
  card.append(el("p", "snippet", snippet || "No text yet."));

  const chip = subjectChip(note);
  const chips = chipRow(note.topics, note.tags);
  if (chip) chips.prepend(chip);
  if (chips.childNodes.length) card.append(chips);

  const count = Array.isArray(note.attachments) ? note.attachments.length : 0;
  const meta = ["Updated " + shortDate(toDate(note.updatedAt))];
  if (count) meta.push(count + (count === 1 ? " attachment" : " attachments"));
  card.append(el("div", "note-meta", meta.join(" · ")));

  card.onclick = () => openView(note);

  return card;
}

function render() {
  const term = $("search").value;
  const subjectFilter = $("filter-subject").value;

  const matches = sortNotes(filterNotes(notes, term, subjectFilter));

  grid.replaceChildren();

  if (matches.length === 0) {
    const nothingYet = notes.length === 0 && subjectFilter === "all" && !term.trim();

    if (nothingYet) {
      grid.append(emptyBox(
        "No notes yet",
        "Write your first note to start building your study library.",
        "New note",
        () => openEditor()
      ));
    } else {
      grid.append(emptyBox("No notes found", "Try a different search or subject."));
    }
  } else {
    matches.forEach((n) => grid.append(noteCard(n)));
  }

  refreshIcons();
}

// Wait a moment after typing so searching never lags
$("search").addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(render, 200);
});

$("filter-subject").addEventListener("change", render);

/* =========================================
   VIEW A NOTE
   ========================================= */

function attachmentRow(file) {
  const isLink = file.kind === "link";

  const row = el("div", "attach");
  row.append(icon(isLink ? "link" : "file-text"));

  const name = el("span", "name", file.name || (isLink ? "Link" : "Untitled file"));

  let details;
  if (isLink) {
    details = [serviceLabel(file.service) + " link"];
  } else {
    details = [formatBytes(file.size)];
    if (typeof file.uploadedAt === "number") {
      details.push(shortDate(new Date(file.uploadedAt)));
    }
  }

  row.append(name, el("span", "size", details.filter(Boolean).join(" · ")));

  return { row, name };
}

function markUnavailable(row, name, file) {
  row.classList.add("missing");
  name.textContent = (file.name || "File") + " – unavailable";
}

// Shows each attachment as a link.
// An old, missing or unsafe one is shown as unavailable (no crash).
function linkAttachments(files, container) {
  for (const file of files) {
    const { row, name } = attachmentRow(file);
    container.append(row);

    // A saved link (checked again before it is used)
    if (file.kind === "link") {
      const parsed = parseLink(file.url);

      if (parsed.error) {
        markUnavailable(row, name, file);
        continue;
      }

      const anchor = el("a", "name", file.name || "Link");
      anchor.href = parsed.url;
      anchor.target = "_blank";
      anchor.rel = "noopener noreferrer";
      name.replaceWith(anchor);
      continue;
    }

    if (!isCloudinaryUrl(file.url)) {
      markUnavailable(row, name, file);
      continue;
    }

    const link = el("a", "name", file.name || "Untitled file");
    link.href = file.url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    name.replaceWith(link);
  }

  refreshIcons();
}

function openView(note) {
  const body = $("view-body");
  body.replaceChildren();

  /* ----- Heading ----- */
  const head = el("div", "view-head");
  head.append(el("h2", "", note.title));

  const chips = chipRow(note.topics, note.tags);
  const chip = subjectChip(note);
  if (chip) chips.prepend(chip);
  if (note.pinned) chips.prepend(el("span", "chip-sm", "Pinned"));
  if (chips.childNodes.length) head.append(chips);

  const dates = el(
    "p", "note-meta",
    "Created " + shortDate(toDate(note.createdAt)) +
    " · Updated " + shortDate(toDate(note.updatedAt))
  );
  dates.style.marginTop = "8px";
  head.append(dates);

  /* ----- Text and word count ----- */
  const section = el("div", "view-section");
  section.append(
    note.content
      ? renderContent(note.content)
      : el("p", "muted", "This note has no text yet.")
  );
  section.append(el("p", "hint count-line", wordLabel(countWords(note.content || ""))));

  body.append(head, section);

  /* ----- Attachments ----- */
  const files = Array.isArray(note.attachments) ? note.attachments : [];

  if (files.length) {
    const box = el("div", "view-section");
    const heading = el("h3", "", "Attachments");
    heading.style.marginBottom = "8px";

    const list = el("div", "attach-list");
    box.append(heading, list);
    body.append(box);

    linkAttachments(files, list);
  }

  /* ----- Buttons ----- */
  const actions = el("div", "view-actions");

  const downloadBtn = el("button", "btn btn-ghost", "Download as .txt");
  downloadBtn.type = "button";
  downloadBtn.onclick = () => {
    const subjectName = subjectsById.get(note.subjectId)?.name || "";
    downloadText(safeFileName(note.title), noteToText(note, subjectName));
  };

  const pinBtn = el("button", "btn btn-ghost", note.pinned ? "Unpin" : "Pin");
  pinBtn.type = "button";
  pinBtn.onclick = () => togglePin(note, pinBtn);

  const editBtn = el("button", "btn btn-ghost", "Edit");
  editBtn.type = "button";
  editBtn.onclick = () => {
    viewDialog.close();
    openEditor(note);
  };

  const deleteBtn = el("button", "btn btn-ghost", "Delete");
  deleteBtn.type = "button";
  deleteBtn.onclick = async () => {
    viewDialog.close();
    const deleted = await removeNote(note);
    if (!deleted) openView(note); // changed their mind: show the note again
  };

  const closeBtn = el("button", "btn btn-primary", "Close");
  closeBtn.type = "button";
  closeBtn.onclick = () => viewDialog.close();

  actions.append(downloadBtn, pinBtn, editBtn, deleteBtn, closeBtn);
  body.append(actions);

  viewDialog.showModal();
  refreshIcons();
}

async function togglePin(note, button) {
  button.disabled = true;

  try {
    const pinned = !note.pinned;

    await updateDoc(userDoc(uid, "notes", note.id), {
      pinned: pinned,
      updatedAt: serverTimestamp()
    });

    note.pinned = pinned;
    button.textContent = pinned ? "Unpin" : "Pin";
    toast(pinned ? "Note pinned." : "Note unpinned.", "success");
    render();
  } catch {
    toast("Could not update the note. Please try again.", "error");
  }

  button.disabled = false;
}

/* =========================================
   BACKGROUND UPLOADS (progress bars)
   The note text is saved first. Files upload after.
   ========================================= */

const jobs = [];       // one per file being uploaded
let pumping = false;

const isBusy = (job) => ["queued", "uploading", "attaching"].includes(job.state);
const hasActiveUpload = (noteId) => jobs.some((j) => j.noteId === noteId && isBusy(j));

// Warn before leaving the page while a file is still uploading
window.addEventListener("beforeunload", (event) => {
  if (jobs.some(isBusy)) {
    event.preventDefault();
    event.returnValue = "";
  }
});

function setJob(job, state, text, percent) {
  job.state = state;
  job.ui.status.textContent = text;
  job.ui.status.classList.toggle("bad", state === "failed");

  if (typeof percent === "number") job.ui.bar.value = percent;

  job.ui.retry.hidden = state !== "failed";
  job.ui.close.hidden = !(state === "failed" || state === "done");
}

function addUploadJob(noteId, noteTitle, item) {
  const row = el("div", "upload-row");

  const close = el("button", "icon-btn");
  close.type = "button";
  close.setAttribute("aria-label", "Dismiss");
  close.append(icon("x"));

  const top = el("div", "upload-top");
  top.append(el("div", "upload-name", item.file.name), close);

  const bar = document.createElement("progress");
  bar.max = 100;
  bar.value = 0;

  const status = el("div", "upload-status");

  const retry = el("button", "btn btn-ghost", "Retry");
  retry.type = "button";

  const foot = el("div", "upload-foot");
  foot.append(status, retry);

  row.append(top, el("div", "upload-note", "Note: " + noteTitle), bar, foot);
  $("upload-tray").append(row);

  const job = {
    noteId,
    file: item.file,
    type: item.type,
    state: "queued",
    result: null,
    ui: { row, bar, status, retry, close }
  };

  retry.onclick = () => {
    setJob(job, "queued", "Waiting…", job.result ? 100 : 0);
    pump();
  };

  close.onclick = () => {
    row.remove();
    const index = jobs.indexOf(job);
    if (index >= 0) jobs.splice(index, 1);
  };

  jobs.push(job);
  setJob(job, "queued", "Waiting…", 0);
  refreshIcons();
}

async function runUpload(job) {
  try {
    // 1. Upload to Cloudinary (skipped on Retry if it already worked)
    if (!job.result) {
      setJob(job, "uploading", "Uploading… 0%", 0);

      job.result = await uploadToCloudinary(job.file, {
        cloudName: CLOUDINARY_CLOUD_NAME,
        preset: CLOUDINARY_UPLOAD_PRESET,
        onProgress: (percent) => {
          setJob(
            job,
            "uploading",
            percent >= 100 ? "Processing…" : `Uploading… ${percent}%`,
            percent
          );
        }
      });
    }

    // 2. Add the file to the note
    setJob(job, "attaching", "Adding to your note…", 100);

    const attachment = {
      url: job.result.url,
      publicId: job.result.publicId,
      resourceType: job.result.resourceType,
      name: job.file.name.split(/[\\/]/).pop().slice(0, 100),
      type: job.type,
      size: job.file.size,
      uploadedAt: Date.now()
    };

    await withTimeout(
      updateDoc(userDoc(uid, "notes", job.noteId), {
        attachments: arrayUnion(attachment),
        updatedAt: serverTimestamp()
      }),
      SAVE_TIMEOUT_MS
    );

    // Update the copy shown on this page
    const note = notes.find((n) => n.id === job.noteId);
    if (note) {
      note.attachments = [...(Array.isArray(note.attachments) ? note.attachments : []), attachment];
      render();
    }

    setJob(job, "done", "Uploaded", 100);
    setTimeout(() => job.ui.close.click(), 4000);
  } catch (err) {
    let reason = "Could not add the file to your note.";

    if (err instanceof UploadError) reason = err.message;
    else if (err instanceof TimeoutError) reason = "Adding the file to your note took too long.";

    // The note text is already saved, so nothing is lost
    setJob(job, "failed", reason + " Your note text is saved.");
  }
}

// Uploads one file at a time
async function pump() {
  if (pumping) return;
  pumping = true;

  for (;;) {
    const job = jobs.find((j) => j.state === "queued");
    if (!job) break;
    await runUpload(job);
  }

  pumping = false;
}

/* =========================================
   EDITOR: form values and drafts
   ========================================= */

function readFields() {
  return {
    title: $("n-title").value,
    subjectId: $("n-subject").value,
    topics: $("n-topics").value,
    tags: $("n-tags").value,
    content: $("n-content").value,
    pinned: $("n-pinned").checked
  };
}

function writeFields(fields) {
  $("n-title").value = fields.title;
  $("n-subject").value = subjectsById.has(fields.subjectId) ? fields.subjectId : "";
  $("n-topics").value = fields.topics;
  $("n-tags").value = fields.tags;
  $("n-content").value = fields.content;
  $("n-pinned").checked = fields.pinned;
}

/* ----- Draft auto-save (kept on this device, text only) ----- */

const draftKey = () => `sh-draft:${uid}:${editing ? editing.id : "new"}`;

function clearDraft() {
  try {
    localStorage.removeItem(draftKey());
  } catch {}
}

function loadDraft() {
  try {
    const raw = localStorage.getItem(draftKey());
    if (!raw) return null;

    const d = JSON.parse(raw);

    const valid =
      d &&
      typeof d.title === "string" &&
      typeof d.subjectId === "string" &&
      typeof d.topics === "string" &&
      typeof d.tags === "string" &&
      typeof d.content === "string" &&
      typeof d.pinned === "boolean" &&
      typeof d.savedAt === "number" &&
      d.content.length <= CONTENT_MAX;

    if (!valid) return null;

    return {
      title: d.title,
      subjectId: d.subjectId,
      topics: d.topics,
      tags: d.tags,
      content: d.content,
      pinned: d.pinned,
      savedAt: d.savedAt
    };
  } catch {
    return null;
  }
}

function saveDraft() {
  const fields = readFields();
  const snapshot = JSON.stringify(fields);

  // Nothing changed since the last save
  if (snapshot === lastSnapshot) return;

  try {
    localStorage.setItem(draftKey(), JSON.stringify({ ...fields, savedAt: Date.now() }));
    lastSnapshot = snapshot;

    const time = new Date().toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
      second: "2-digit"
    });
    $("draft-status").textContent = "Draft saved " + time;
  } catch {
    $("draft-status").textContent = "Draft could not be saved (browser storage is full or blocked).";
  }
}

function restoreDraft() {
  const draft = loadDraft();
  if (!draft) return;

  const { savedAt, ...fields } = draft;

  const updated =
    editing && editing.updatedAt && typeof editing.updatedAt.toMillis === "function"
      ? editing.updatedAt.toMillis()
      : 0;

  // Ignore drafts that are older than the saved note, or the same as it
  if (savedAt < updated || JSON.stringify(fields) === lastSnapshot) {
    clearDraft();
    return;
  }

  writeFields(fields);
  lastSnapshot = JSON.stringify(readFields());
  $("draft-status").textContent = "Restored your unsaved draft.";
}

function stopDraftTimer() {
  clearInterval(draftTimer);
  draftTimer = null;
}

/* ----- Word count ----- */

function updateCount() {
  $("word-count").textContent = wordLabel(countWords($("n-content").value));
}

$("n-content").addEventListener("input", () => {
  clearTimeout(countTimer);
  countTimer = setTimeout(updateCount, 150);
});

/* ----- Edit | Preview ----- */

function setMode(mode) {
  const preview = mode === "preview";

  $("mode-edit").setAttribute("aria-selected", String(!preview));
  $("mode-preview").setAttribute("aria-selected", String(preview));
  $("n-content").hidden = preview;
  $("n-preview").hidden = !preview;

  if (preview) {
    const text = $("n-content").value;

    $("n-preview").replaceChildren(
      text.trim() ? renderContent(text) : el("p", "muted", "Nothing to preview yet.")
    );
  }
}

$("mode-edit").addEventListener("click", () => setMode("edit"));
$("mode-preview").addEventListener("click", () => setMode("preview"));

/* =========================================
   EDITOR: attachments (A: upload a file, B: add a link)
   ========================================= */

// Switch between A) Upload file and B) Add link
function setAttachMode(mode) {
  const isLink = mode === "link";

  $("att-file-tab").setAttribute("aria-selected", String(!isLink));
  $("att-link-tab").setAttribute("aria-selected", String(isLink));
  $("att-file-panel").hidden = isLink;
  $("att-link-panel").hidden = !isLink;
}

$("att-file-tab").addEventListener("click", () => setAttachMode("file"));
$("att-link-tab").addEventListener("click", () => setAttachMode("link"));

function renderExistingFiles() {
  const box = $("attach-existing");
  box.replaceChildren();

  keptFiles.forEach((file, index) => {
    const { row } = attachmentRow(file);

    const removeBtn = el("button", "icon-btn");
    removeBtn.type = "button";
    removeBtn.setAttribute("aria-label", "Remove " + (file.name || "file"));
    removeBtn.append(icon("x"));
    removeBtn.onclick = () => {
      keptFiles.splice(index, 1);
      renderExistingFiles();
    };

    row.append(removeBtn);
    box.append(row);
  });

  refreshIcons();
}

function renderPendingFiles() {
  const box = $("attach-pending");
  box.replaceChildren();

  pending.forEach((item, index) => {
    const row = el("div", "attach");
    row.append(icon("upload"));
    row.append(
      el("span", "name", item.file.name),
      el("span", "size", formatBytes(item.file.size))
    );

    const removeBtn = el("button", "icon-btn");
    removeBtn.type = "button";
    removeBtn.setAttribute("aria-label", "Remove " + item.file.name);
    removeBtn.append(icon("x"));
    removeBtn.onclick = () => {
      pending.splice(index, 1);
      renderPendingFiles();
    };

    row.append(removeBtn);
    box.append(row);
  });

  if (pending.length) {
    box.append(el("p", "hint", "These upload when you tap Save note."));
  }

  refreshIcons();
}

// Files are checked the moment they are picked
$("n-files").addEventListener("change", async (e) => {
  const picked = Array.from(e.target.files);
  e.target.value = ""; // so the same file can be picked again

  if (picked.length === 0) return;

  const { accepted, rejected } = await screenFiles(
    picked,
    keptFiles.length + pending.length
  );

  pending.push(...accepted);
  renderPendingFiles();
  fieldError($("n-files"), rejected.join("\n"));

  if (rejected.length) {
    toast(
      rejected[0] + (rejected.length > 1 ? ` (+${rejected.length - 1} more)` : ""),
      "error",
      6000
    );
  }
});

// B) A link needs a title and a web address. Nothing is uploaded.
$("add-link-btn").addEventListener("click", () => {
  const title = $("n-link-title").value.trim().replace(/\s+/g, " ");
  const parsed = parseLink($("n-link").value);
  const titleOk = title.length >= 1 && title.length <= 60;

  fieldError($("n-link-title"), titleOk ? "" : "Enter a title (up to 60 characters).");
  fieldError($("n-link"), parsed.error || "");

  if (!titleOk || parsed.error) return;

  if (keptFiles.length + pending.length >= MAX_FILES) {
    fieldError($("n-link"), `You can attach up to ${MAX_FILES} attachments per note.`);
    return;
  }

  keptFiles.push({
    kind: "link",
    service: parsed.service,
    name: title,
    url: parsed.url,
    type: "link",
    uploadedAt: Date.now()
  });

  $("n-link-title").value = "";
  $("n-link").value = "";
  renderExistingFiles();
});

/* =========================================
   EDITOR: open, cancel, save
   ========================================= */

function openEditor(note) {
  // A file is still uploading to this note: editing now could lose it
  if (note && hasActiveUpload(note.id)) {
    toast("This note is still uploading a file. Wait for it to finish, then edit.", "warning");
    return;
  }

  stopDraftTimer();

  editing = note || null;
  keptFiles = note && Array.isArray(note.attachments) ? [...note.attachments] : [];
  pending = [];

  // New notes start in the subject being filtered
  const filter = $("filter-subject").value;
  const defaultSubject = subjectsById.has(filter) ? filter : "";

  $("editor-title").textContent = note ? "Edit note" : "New note";

  writeFields({
    title: note ? note.title : "",
    subjectId: note ? note.subjectId || "" : defaultSubject,
    topics: note ? (note.topics || []).join(", ") : "",
    tags: note ? (note.tags || []).join(", ") : "",
    content: note ? note.content || "" : "",
    pinned: note ? note.pinned === true : false
  });

  lastSnapshot = JSON.stringify(readFields());
  $("draft-status").textContent = "";
  restoreDraft();

  $("n-link-title").value = "";
  $("n-link").value = "";

  ["n-title", "n-topics", "n-tags", "n-content", "n-files", "n-link-title", "n-link"].forEach((id) => {
    fieldError($(id), "");
  });

  setMode("edit");
  setAttachMode("file");
  updateCount();
  renderExistingFiles();
  renderPendingFiles();

  editorDialog.showModal();
  $("n-title").focus();

  draftTimer = setInterval(saveDraft, DRAFT_EVERY_MS);
}

$("add-btn").addEventListener("click", () => openEditor());

// Cancel throws the draft away
$("cancel-btn").addEventListener("click", () => {
  stopDraftTimer();
  clearDraft();
  editorDialog.close();
});

// Closed another way (for example the Escape key): keep the draft
editorDialog.addEventListener("close", () => {
  if (draftTimer) {
    saveDraft();
    stopDraftTimer();
  }
});

$("note-form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const title = $("n-title").value.trim().replace(/\s+/g, " ");
  const content = $("n-content").value;
  const topics = parseList($("n-topics").value, 20, 40, "topic");
  const tags = parseList($("n-tags").value, 20, 30, "tag");
  const button = $("save-btn");

  /* ----- Check the form ----- */
  const errors = checkNote(title, content);

  fieldError($("n-title"), errors.title || "");
  fieldError($("n-content"), errors.content || "");
  fieldError($("n-topics"), topics.error || "");
  fieldError($("n-tags"), tags.error || "");

  if (errors.title) {
    toast(errors.title, "warning");
    $("n-title").focus();
  }

  if (errors.title || errors.content || topics.error || tags.error) return;

  // A link was typed but "Add link" was not tapped
  if ($("n-link").value.trim() || $("n-link-title").value.trim()) {
    setAttachMode("link");
    fieldError($("n-link"), "Tap Add link to attach this link, or clear both boxes.");
    return;
  }

  if (keptFiles.length + pending.length > MAX_FILES) {
    fieldError($("n-files"), `You can attach up to ${MAX_FILES} attachments per note.`);
    return;
  }

  setLoading(button, true);

  /* ----- 1. Save the text FIRST (links are saved with it) ----- */
  const data = {
    subjectId: $("n-subject").value,
    title: title,
    content: content,
    topics: topics.items,
    tags: tags.items,
    pinned: $("n-pinned").checked,
    attachments: keptFiles,
    updatedAt: serverTimestamp()
  };

  const wasEditing = editing !== null;
  let noteId;

  try {
    if (editing) {
      await withTimeout(updateDoc(userDoc(uid, "notes", editing.id), data), SAVE_TIMEOUT_MS);
      noteId = editing.id;
    } else {
      const created = await withTimeout(
        addDoc(userCol(uid, "notes"), { ownerId: uid, ...data, createdAt: serverTimestamp() }),
        SAVE_TIMEOUT_MS
      );
      noteId = created.id;
    }
  } catch (err) {
    // Not saved: the editor stays open and the draft is kept
    setLoading(button, false, "Save note");

    toast(
      err instanceof TimeoutError
        ? "Saving is taking too long. Check your connection, then tap Save again. Your text is kept as a draft."
        : "Could not save the note. Please try again.",
      "error",
      8000
    );
    return;
  }

  /* ----- Text is saved: close the editor ----- */
  const queued = pending.slice();

  stopDraftTimer();
  clearDraft();
  editorDialog.close();
  setLoading(button, false, "Save note");

  const saved = wasEditing ? "Note updated." : "Note saved.";
  toast(queued.length ? saved + " Uploading your files in the background…" : saved, "success");

  await loadAll();

  /* ----- 2. Upload the files in the background ----- */
  if (queued.length) {
    queued.forEach((item) => addUploadJob(noteId, title, item));
    pump();
  }
});

/* =========================================
   DELETE (asks "Are you sure?" first)
   ========================================= */

// Returns true if the note was deleted
async function removeNote(note) {
  if (hasActiveUpload(note.id)) {
    toast("This note is still uploading a file. Wait for it to finish first.", "warning");
    return false;
  }

  const confirmed = await confirmModal({
    title: "Are you sure?",
    message: `Delete "${note.title}"? This cannot be undone. Uploaded files stay in your Cloudinary library.`,
    confirmText: "Yes, delete",
    danger: true
  });

  if (!confirmed) return false;

  try {
    await deleteDoc(userDoc(uid, "notes", note.id));
    toast("Note deleted.", "success");
    await loadAll();
    return true;
  } catch {
    toast("Could not delete the note. Please try again.", "error");
    return false;
  }
}

/* ---------- Go ---------- */

loadAll();