// Calendar page script: grid view, navigation, subject filtering, add/edit/delete events.
import { requireAuth } from "./auth-guard.js";
import { renderShell } from "./layout.js";
import { userCol, userDoc, safeColor, toDate } from "./firestore.js";
import { el, icon, refreshIcons } from "./dom.js";
import { toast, confirmModal, setLoading, fieldError } from "./utils.js";
import { EVENT_TYPES, toDateTimeLocal, isSameDay, getCalendarGridDays, filterEvents, checkEvent } from "./calendar-logic.js";
import { getDocs, addDoc, updateDoc, deleteDoc, query, orderBy, limit, serverTimestamp, Timestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $ = (id) => document.getElementById(id);

/* ---------- Authentication & Page Shell ---------- */
const user = await requireAuth();
const uid = user.uid;
renderShell(user, "calendar.html");

/* ---------- Timeout Protection ---------- */
const SAVE_TIMEOUT_MS = 15000;
class TimeoutError extends Error {}
function withTimeout(promise, ms) {
  let timer;
  const limitPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new TimeoutError("Timed out")), ms);
  });
  return Promise.race([promise, limitPromise]).finally(() => clearTimeout(timer));
}

/* ---------- App State ---------- */
let events = [];
let subjectsById = new Map();
let currentDate = new Date();
let editing = null;

const gridEl = $("cal-grid");
const monthYearEl = $("cal-month-year");
const dialog = $("event-dialog");

/* =========================================
   DOM HELPERS
========================================= */
function addOption(select, value, label) {
  if (!select) return;
  const option = document.createElement("option");
  option.value = value;
  option.textContent = label;
  select.append(option);
}

/* =========================================
   DATA LOADING
========================================= */
function fillSubjectSelects() {
  const filter = $("cal-filter-subject");
  const picker = $("e-subject");

  if (filter) {
    const currentFilter = filter.value;
    filter.replaceChildren();
    addOption(filter, "all", "All subjects");
    addOption(filter, "none", "No subject");
    for (const [id, subject] of subjectsById) {
      addOption(filter, id, subject.name);
    }
    filter.value = subjectsById.has(currentFilter) || currentFilter === "none" ? currentFilter : "all";
  }

  if (picker) {
    picker.replaceChildren();
    addOption(picker, "", "No subject");
    for (const [id, subject] of subjectsById) {
      addOption(picker, id, subject.name);
    }
  }
}

async function loadAll() {
  try {
    const [subjectSnap, eventSnap] = await Promise.all([
      getDocs(query(userCol(uid, "subjects"), orderBy("name"), limit(200))),
      getDocs(query(userCol(uid, "events"), orderBy("start", "asc"), limit(500)))
    ]);

    subjectsById = new Map(subjectSnap.docs.map((d) => [d.id, d.data()]));
    events = eventSnap.docs.map((d) => {
      const data = d.data();
      return { id: d.id, ...data, start: toDate(data.start), end: toDate(data.end) };
    });

    fillSubjectSelects();
    renderCalendar();
  } catch (err) {
    console.error("Calendar load error:", err);
    toast("Could not load calendar events.", "error");
  }
}

/* =========================================
   CALENDAR RENDERING - FIXED
========================================= */
function renderCalendar() {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  if (monthYearEl) {
    monthYearEl.textContent = currentDate.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  }
  if (!gridEl) return;

  gridEl.replaceChildren();
  const today = new Date();
  const subjectFilter = $("cal-filter-subject") ? $("cal-filter-subject").value : "all";
  const visibleEvents = filterEvents(events, subjectFilter);
  const gridDays = getCalendarGridDays(year, month);

  gridDays.forEach(({ date, isCurrentMonth }) => {
    const cell = el("div", "cal-day");
    if (!isCurrentMonth) cell.classList.add("other-month");
    if (isSameDay(date, today)) cell.classList.add("today");

    const numberDiv = el("div", "cal-day-number", String(date.getDate()));
    cell.append(numberDiv);

    const eventsBox = el("div", "cal-events");
    const dayEvents = visibleEvents.filter((e) => isSameDay(e.start, date));

    dayEvents.forEach((evt) => {
      const subject = subjectsById.get(evt.subjectId);
      const eventBadge = el("div", "cal-event", evt.title);

      // FIX: Set data-type so CSS color works
      eventBadge.dataset.type = evt.type || "other";

      // FIX: Don't override border color with subject color anymore.
      // Type color from CSS will now show. Subject name still in tooltip.
      eventBadge.title = evt.title + (subject ? ` (${subject.name})` : "") + (evt.type ? ` - ${evt.type}` : "");

      eventBadge.onclick = (e) => {
        e.stopPropagation();
        openDialog(evt);
      };
      eventsBox.append(eventBadge);
    });

    cell.append(eventsBox);
    cell.onclick = () => openDialog(null, date);
    gridEl.append(cell);
  });

  refreshIcons();
}

/* =========================================
   NAVIGATION
========================================= */
if ($("cal-prev")) {
  $("cal-prev").addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
  });
}
if ($("cal-next")) {
  $("cal-next").addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
  });
}
if ($("cal-today-btn")) {
  $("cal-today-btn").addEventListener("click", () => {
    currentDate = new Date();
    renderCalendar();
  });
}
if ($("cal-filter-subject")) {
  $("cal-filter-subject").addEventListener("change", renderCalendar);
}

/* =========================================
   DIALOG: ADD / EDIT / DELETE
========================================= */
function openDialog(eventData = null, defaultDate = null) {
  if (!dialog) return;
  editing = eventData || null;

  if ($("event-title")) $("event-title").textContent = editing ? "Edit event" : "Add event";
  if ($("e-title")) $("e-title").value = editing ? editing.title : "";
  if ($("e-subject")) $("e-subject").value = editing && subjectsById.has(editing.subjectId) ? editing.subjectId : "";
  if ($("e-type")) $("e-type").value = editing ? editing.type || "exam" : "exam";
  if ($("e-desc")) $("e-desc").value = editing ? editing.description || "" : "";

  const deleteBtn = $("e-delete");
  if (deleteBtn) {
    deleteBtn.style.display = editing ? "inline-flex" : "none";
  }

  if (editing && editing.start) {
    if ($("e-start")) $("e-start").value = toDateTimeLocal(editing.start);
    if ($("e-end")) $("e-end").value = editing.end ? toDateTimeLocal(editing.end) : "";
  } else if (defaultDate) {
    const start = new Date(defaultDate);
    start.setHours(9, 0, 0, 0);
    if ($("e-start")) $("e-start").value = toDateTimeLocal(start);
    if ($("e-end")) $("e-end").value = "";
  } else {
    if ($("e-start")) $("e-start").value = toDateTimeLocal(new Date());
    if ($("e-end")) $("e-end").value = "";
  }

  ["e-title", "e-start", "e-end", "e-desc"].forEach((id) => {
    const field = $(id);
    if (field) fieldError(field, "");
  });

  dialog.showModal();
  if ($("e-title")) $("e-title").focus();
}

const addBtn = $("add-btn") || $("add-event-btn");
if (addBtn) {
  addBtn.addEventListener("click", () => openDialog());
}

if ($("e-cancel")) {
  $("e-cancel").addEventListener("click", () => dialog.close());
}

// FIX: Close dialog when clicking outside / backdrop
if (dialog) {
  dialog.addEventListener("click", (e) => {
    if (e.target === dialog) dialog.close();
  });
}

if ($("event-form")) {
  $("event-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const title = $("e-title") ? $("e-title").value : "";
    const startDateText = $("e-start") ? $("e-start").value : "";
    const endDateText = $("e-end") ? $("e-end").value : "";
    const type = $("e-type") ? $("e-type").value : "exam";
    const subjectId = $("e-subject") ? $("e-subject").value : "";
    const description = $("e-desc") ? $("e-desc").value.trim() : "";

    const { errors, values } = checkEvent({ title, startDateText, endDateText, type });

    if ($("e-title")) fieldError($("e-title"), errors.title || "");
    if ($("e-start")) fieldError($("e-start"), errors.start || "");
    if ($("e-end")) fieldError($("e-end"), errors.end || "");
    if (Object.keys(errors).length > 0) return;

    const saveBtn = $("e-save");
    if (saveBtn) setLoading(saveBtn, true);

    const fields = {
      ownerId: uid,
      subjectId: subjectId || null,
      title: values.title,
      type: values.type,
      start: Timestamp.fromDate(values.start),
      end: values.end ? Timestamp.fromDate(values.end) : null,
      description,
      updatedAt: serverTimestamp()
    };

    try {
      if (editing) {
        await withTimeout(updateDoc(userDoc(uid, "events", editing.id), fields), SAVE_TIMEOUT_MS);
        toast("Event updated.", "success");
      } else {
        fields.createdAt = serverTimestamp();
        await withTimeout(addDoc(userCol(uid, "events"), fields), SAVE_TIMEOUT_MS);
        toast("Event added.", "success");
      }
      dialog.close();
      await loadAll();
    } catch (err) {
      toast(err instanceof TimeoutError ? "Saving took too long. Check your connection." : "Could not save event. Try again.", "error");
    } finally {
      if (saveBtn) setLoading(saveBtn, false, "Save event");
    }
  });
}

const deleteBtn = $("e-delete");
if (deleteBtn) {
  deleteBtn.addEventListener("click", async () => {
    if (!editing) return;
    const confirmed = await confirmModal({
      title: "Delete event?",
      message: `Are you sure you want to delete "${editing.title}"?`,
      confirmText: "Delete",
      danger: true
    });
    if (!confirmed) return;
    try {
      await withTimeout(deleteDoc(userDoc(uid, "events", editing.id)), SAVE_TIMEOUT_MS);
      toast("Event deleted.", "success");
      dialog.close();
      await loadAll();
    } catch {
      toast("Could not delete event.", "error");
    }
  });
}

/* ---------- Setup & Start ---------- */
loadAll();