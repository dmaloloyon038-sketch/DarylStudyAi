// Shared Firestore helpers and constants.

import { db } from "./firebase-config.js";

import {
  collection,
  doc
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

/* ---------- Paths: everything lives under users/{uid} ---------- */

export const userCol = (uid, name) => collection(db, "users", uid, name);
export const userDoc = (uid, name, id) => doc(db, "users", uid, name, id);

/* ---------- Subject colors ---------- */

export const SUBJECT_COLORS = [
  "#9585D5", "#E8B7C5", "#A6C9B8", "#F2C99B",
  "#7FB3D5", "#C9A0DC", "#F28B82", "#8FD1D6"
];

export const DEFAULT_COLOR = "#9585D5";

export function isHexColor(color) {
  return typeof color === "string" && /^#[0-9A-Fa-f]{6}$/.test(color);
}

// Never put an unchecked color into a style
export function safeColor(color) {
  return isHexColor(color) ? color : DEFAULT_COLOR;
}

/* ---------- ID check (used for ?id= in the address bar) ---------- */

export function isValidId(id) {
  return typeof id === "string" && /^[A-Za-z0-9]{1,40}$/.test(id);
}

/* ---------- Dates ---------- */

// Firestore timestamp -> JavaScript Date (or null)
export function toDate(value) {
  return value && typeof value.toDate === "function" ? value.toDate() : null;
}

export function shortDate(date) {
  if (!date) return "";
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function shortDateTime(date) {
  if (!date) return "";
  const time = date.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit"
  });
  return shortDate(date) + ", " + time;
}

/* ---------- File sizes ---------- */

export function formatBytes(bytes) {
  if (typeof bytes !== "number" || bytes < 0) return "";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}